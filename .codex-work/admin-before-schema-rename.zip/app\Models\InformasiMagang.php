<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InformasiMagang extends Model
{
    use HasFactory;

    protected $table = 'informasi_magang';
    public $timestamps = false;
    public $incrementing = false;

    protected $fillable = [
        'id',
        'perusahaan',
        'posisi',
        'durasi',
    ];

    public function informasi()
    {
        return $this->belongsTo(Informasi::class, 'id', 'id');
    }
}
