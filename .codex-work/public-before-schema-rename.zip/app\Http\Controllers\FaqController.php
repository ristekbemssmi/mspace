<?php

namespace App\Http\Controllers;

use App\Models\Faq;
use Inertia\Inertia;
use Inertia\Response;

class FaqController extends Controller
{
    public function index(): Response
    {
        $faqs = Faq::query()
            ->where('is_active', true)
            ->orderBy('urutan', 'asc')
            ->get(['id', 'pertanyaan', 'jawaban']);

        return Inertia::render('Faq/Index', [
            'faqs' => $faqs,
        ]);
    }
}
