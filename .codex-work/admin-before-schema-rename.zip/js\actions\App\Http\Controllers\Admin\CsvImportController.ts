import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\CsvImportController::index
 * @see app/Http/Controllers/Admin/CsvImportController.php:22
 * @route '/admin/csv-hub'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/csv-hub',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CsvImportController::index
 * @see app/Http/Controllers/Admin/CsvImportController.php:22
 * @route '/admin/csv-hub'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CsvImportController::index
 * @see app/Http/Controllers/Admin/CsvImportController.php:22
 * @route '/admin/csv-hub'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\CsvImportController::index
 * @see app/Http/Controllers/Admin/CsvImportController.php:22
 * @route '/admin/csv-hub'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\CsvImportController::index
 * @see app/Http/Controllers/Admin/CsvImportController.php:22
 * @route '/admin/csv-hub'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\CsvImportController::index
 * @see app/Http/Controllers/Admin/CsvImportController.php:22
 * @route '/admin/csv-hub'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\CsvImportController::index
 * @see app/Http/Controllers/Admin/CsvImportController.php:22
 * @route '/admin/csv-hub'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\CsvImportController::processImport
 * @see app/Http/Controllers/Admin/CsvImportController.php:31
 * @route '/admin/csv-hub/process'
 */
export const processImport = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: processImport.url(options),
    method: 'post',
})

processImport.definition = {
    methods: ["post"],
    url: '/admin/csv-hub/process',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\CsvImportController::processImport
 * @see app/Http/Controllers/Admin/CsvImportController.php:31
 * @route '/admin/csv-hub/process'
 */
processImport.url = (options?: RouteQueryOptions) => {
    return processImport.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CsvImportController::processImport
 * @see app/Http/Controllers/Admin/CsvImportController.php:31
 * @route '/admin/csv-hub/process'
 */
processImport.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: processImport.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\CsvImportController::processImport
 * @see app/Http/Controllers/Admin/CsvImportController.php:31
 * @route '/admin/csv-hub/process'
 */
    const processImportForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: processImport.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\CsvImportController::processImport
 * @see app/Http/Controllers/Admin/CsvImportController.php:31
 * @route '/admin/csv-hub/process'
 */
        processImportForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: processImport.url(options),
            method: 'post',
        })
    
    processImport.form = processImportForm
/**
* @see \App\Http\Controllers\Admin\CsvImportController::downloadTemplate
 * @see app/Http/Controllers/Admin/CsvImportController.php:69
 * @route '/admin/csv-hub/template/{tableName}'
 */
export const downloadTemplate = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadTemplate.url(args, options),
    method: 'get',
})

downloadTemplate.definition = {
    methods: ["get","head"],
    url: '/admin/csv-hub/template/{tableName}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CsvImportController::downloadTemplate
 * @see app/Http/Controllers/Admin/CsvImportController.php:69
 * @route '/admin/csv-hub/template/{tableName}'
 */
downloadTemplate.url = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { tableName: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    tableName: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        tableName: args.tableName,
                }

    return downloadTemplate.definition.url
            .replace('{tableName}', parsedArgs.tableName.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CsvImportController::downloadTemplate
 * @see app/Http/Controllers/Admin/CsvImportController.php:69
 * @route '/admin/csv-hub/template/{tableName}'
 */
downloadTemplate.get = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadTemplate.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\CsvImportController::downloadTemplate
 * @see app/Http/Controllers/Admin/CsvImportController.php:69
 * @route '/admin/csv-hub/template/{tableName}'
 */
downloadTemplate.head = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloadTemplate.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\CsvImportController::downloadTemplate
 * @see app/Http/Controllers/Admin/CsvImportController.php:69
 * @route '/admin/csv-hub/template/{tableName}'
 */
    const downloadTemplateForm = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: downloadTemplate.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\CsvImportController::downloadTemplate
 * @see app/Http/Controllers/Admin/CsvImportController.php:69
 * @route '/admin/csv-hub/template/{tableName}'
 */
        downloadTemplateForm.get = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadTemplate.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\CsvImportController::downloadTemplate
 * @see app/Http/Controllers/Admin/CsvImportController.php:69
 * @route '/admin/csv-hub/template/{tableName}'
 */
        downloadTemplateForm.head = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadTemplate.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    downloadTemplate.form = downloadTemplateForm
/**
* @see \App\Http\Controllers\Admin\CsvImportController::downloadTemplateXlsx
 * @see app/Http/Controllers/Admin/CsvImportController.php:58
 * @route '/admin/csv-hub/template-xlsx/{tableName}'
 */
export const downloadTemplateXlsx = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadTemplateXlsx.url(args, options),
    method: 'get',
})

downloadTemplateXlsx.definition = {
    methods: ["get","head"],
    url: '/admin/csv-hub/template-xlsx/{tableName}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CsvImportController::downloadTemplateXlsx
 * @see app/Http/Controllers/Admin/CsvImportController.php:58
 * @route '/admin/csv-hub/template-xlsx/{tableName}'
 */
downloadTemplateXlsx.url = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { tableName: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    tableName: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        tableName: args.tableName,
                }

    return downloadTemplateXlsx.definition.url
            .replace('{tableName}', parsedArgs.tableName.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CsvImportController::downloadTemplateXlsx
 * @see app/Http/Controllers/Admin/CsvImportController.php:58
 * @route '/admin/csv-hub/template-xlsx/{tableName}'
 */
downloadTemplateXlsx.get = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadTemplateXlsx.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\CsvImportController::downloadTemplateXlsx
 * @see app/Http/Controllers/Admin/CsvImportController.php:58
 * @route '/admin/csv-hub/template-xlsx/{tableName}'
 */
downloadTemplateXlsx.head = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloadTemplateXlsx.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\CsvImportController::downloadTemplateXlsx
 * @see app/Http/Controllers/Admin/CsvImportController.php:58
 * @route '/admin/csv-hub/template-xlsx/{tableName}'
 */
    const downloadTemplateXlsxForm = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: downloadTemplateXlsx.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\CsvImportController::downloadTemplateXlsx
 * @see app/Http/Controllers/Admin/CsvImportController.php:58
 * @route '/admin/csv-hub/template-xlsx/{tableName}'
 */
        downloadTemplateXlsxForm.get = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadTemplateXlsx.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\CsvImportController::downloadTemplateXlsx
 * @see app/Http/Controllers/Admin/CsvImportController.php:58
 * @route '/admin/csv-hub/template-xlsx/{tableName}'
 */
        downloadTemplateXlsxForm.head = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadTemplateXlsx.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    downloadTemplateXlsx.form = downloadTemplateXlsxForm
/**
* @see \App\Http\Controllers\Admin\CsvImportController::exportTable
 * @see app/Http/Controllers/Admin/CsvImportController.php:80
 * @route '/admin/csv-hub/export/{tableName}'
 */
export const exportTable = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportTable.url(args, options),
    method: 'get',
})

exportTable.definition = {
    methods: ["get","head"],
    url: '/admin/csv-hub/export/{tableName}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CsvImportController::exportTable
 * @see app/Http/Controllers/Admin/CsvImportController.php:80
 * @route '/admin/csv-hub/export/{tableName}'
 */
exportTable.url = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { tableName: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    tableName: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        tableName: args.tableName,
                }

    return exportTable.definition.url
            .replace('{tableName}', parsedArgs.tableName.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CsvImportController::exportTable
 * @see app/Http/Controllers/Admin/CsvImportController.php:80
 * @route '/admin/csv-hub/export/{tableName}'
 */
exportTable.get = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportTable.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\CsvImportController::exportTable
 * @see app/Http/Controllers/Admin/CsvImportController.php:80
 * @route '/admin/csv-hub/export/{tableName}'
 */
exportTable.head = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportTable.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\CsvImportController::exportTable
 * @see app/Http/Controllers/Admin/CsvImportController.php:80
 * @route '/admin/csv-hub/export/{tableName}'
 */
    const exportTableForm = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportTable.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\CsvImportController::exportTable
 * @see app/Http/Controllers/Admin/CsvImportController.php:80
 * @route '/admin/csv-hub/export/{tableName}'
 */
        exportTableForm.get = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportTable.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\CsvImportController::exportTable
 * @see app/Http/Controllers/Admin/CsvImportController.php:80
 * @route '/admin/csv-hub/export/{tableName}'
 */
        exportTableForm.head = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportTable.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportTable.form = exportTableForm
const CsvImportController = { index, processImport, downloadTemplate, downloadTemplateXlsx, exportTable }

export default CsvImportController