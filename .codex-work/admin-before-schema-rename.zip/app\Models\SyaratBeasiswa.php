<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SyaratBeasiswa extends Model
{
    use HasFactory;

    protected $table = 'syarat_beasiswa';
    public $timestamps = false;

    protected $fillable = [
        'id_beasiswa',
        'nama_syarat',
        'keterangan',
    ];

    public function beasiswa()
    {
        return $this->belongsTo(InformasiBeasiswa::class, 'id_beasiswa', 'id');
    }
}
