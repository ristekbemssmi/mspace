<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InformasiWisuda extends Model
{
    use HasFactory;

    protected $table = 'informasi_wisuda';
    public $timestamps = false;
    public $incrementing = false;

    protected $fillable = [
        'id',
        'periode_wisuda',
        'alur_pendaftaran',
    ];

    public function informasi()
    {
        return $this->belongsTo(Informasi::class, 'id', 'id');
    }
}
