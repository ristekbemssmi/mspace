import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../wayfinder'
/**
* @see \App\Http\Controllers\HomeController::home
 * @see app/Http/Controllers/HomeController.php:11
 * @route '/'
 */
export const home = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})

home.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HomeController::home
 * @see app/Http/Controllers/HomeController.php:11
 * @route '/'
 */
home.url = (options?: RouteQueryOptions) => {
    return home.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HomeController::home
 * @see app/Http/Controllers/HomeController.php:11
 * @route '/'
 */
home.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\HomeController::home
 * @see app/Http/Controllers/HomeController.php:11
 * @route '/'
 */
home.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: home.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\HomeController::home
 * @see app/Http/Controllers/HomeController.php:11
 * @route '/'
 */
    const homeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: home.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\HomeController::home
 * @see app/Http/Controllers/HomeController.php:11
 * @route '/'
 */
        homeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\HomeController::home
 * @see app/Http/Controllers/HomeController.php:11
 * @route '/'
 */
        homeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    home.form = homeForm
/**
* @see \App\Http\Controllers\BirdeptController::bemssmi
 * @see app/Http/Controllers/BirdeptController.php:27
 * @route '/bemssmi'
 */
export const bemssmi = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: bemssmi.url(options),
    method: 'get',
})

bemssmi.definition = {
    methods: ["get","head"],
    url: '/bemssmi',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BirdeptController::bemssmi
 * @see app/Http/Controllers/BirdeptController.php:27
 * @route '/bemssmi'
 */
bemssmi.url = (options?: RouteQueryOptions) => {
    return bemssmi.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BirdeptController::bemssmi
 * @see app/Http/Controllers/BirdeptController.php:27
 * @route '/bemssmi'
 */
bemssmi.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: bemssmi.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\BirdeptController::bemssmi
 * @see app/Http/Controllers/BirdeptController.php:27
 * @route '/bemssmi'
 */
bemssmi.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: bemssmi.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\BirdeptController::bemssmi
 * @see app/Http/Controllers/BirdeptController.php:27
 * @route '/bemssmi'
 */
    const bemssmiForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: bemssmi.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\BirdeptController::bemssmi
 * @see app/Http/Controllers/BirdeptController.php:27
 * @route '/bemssmi'
 */
        bemssmiForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: bemssmi.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\BirdeptController::bemssmi
 * @see app/Http/Controllers/BirdeptController.php:27
 * @route '/bemssmi'
 */
        bemssmiForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: bemssmi.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    bemssmi.form = bemssmiForm
/**
* @see \App\Http\Controllers\FaqController::faq
 * @see app/Http/Controllers/FaqController.php:11
 * @route '/faq'
 */
export const faq = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: faq.url(options),
    method: 'get',
})

faq.definition = {
    methods: ["get","head"],
    url: '/faq',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FaqController::faq
 * @see app/Http/Controllers/FaqController.php:11
 * @route '/faq'
 */
faq.url = (options?: RouteQueryOptions) => {
    return faq.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FaqController::faq
 * @see app/Http/Controllers/FaqController.php:11
 * @route '/faq'
 */
faq.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: faq.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\FaqController::faq
 * @see app/Http/Controllers/FaqController.php:11
 * @route '/faq'
 */
faq.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: faq.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\FaqController::faq
 * @see app/Http/Controllers/FaqController.php:11
 * @route '/faq'
 */
    const faqForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: faq.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\FaqController::faq
 * @see app/Http/Controllers/FaqController.php:11
 * @route '/faq'
 */
        faqForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: faq.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\FaqController::faq
 * @see app/Http/Controllers/FaqController.php:11
 * @route '/faq'
 */
        faqForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: faq.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    faq.form = faqForm
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/akademik'
 */
export const akademik = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: akademik.url(options),
    method: 'get',
})

akademik.definition = {
    methods: ["get","head"],
    url: '/akademik',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/akademik'
 */
akademik.url = (options?: RouteQueryOptions) => {
    return akademik.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/akademik'
 */
akademik.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: akademik.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/akademik'
 */
akademik.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: akademik.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/akademik'
 */
    const akademikForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: akademik.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/akademik'
 */
        akademikForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: akademik.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/akademik'
 */
        akademikForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: akademik.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    akademik.form = akademikForm
/**
* @see \App\Http\Controllers\BeasiswaController::informasiBeasiswa
 * @see app/Http/Controllers/BeasiswaController.php:10
 * @route '/informasi-beasiswa'
 */
export const informasiBeasiswa = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: informasiBeasiswa.url(options),
    method: 'get',
})

informasiBeasiswa.definition = {
    methods: ["get","head"],
    url: '/informasi-beasiswa',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BeasiswaController::informasiBeasiswa
 * @see app/Http/Controllers/BeasiswaController.php:10
 * @route '/informasi-beasiswa'
 */
informasiBeasiswa.url = (options?: RouteQueryOptions) => {
    return informasiBeasiswa.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BeasiswaController::informasiBeasiswa
 * @see app/Http/Controllers/BeasiswaController.php:10
 * @route '/informasi-beasiswa'
 */
informasiBeasiswa.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: informasiBeasiswa.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\BeasiswaController::informasiBeasiswa
 * @see app/Http/Controllers/BeasiswaController.php:10
 * @route '/informasi-beasiswa'
 */
informasiBeasiswa.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: informasiBeasiswa.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\BeasiswaController::informasiBeasiswa
 * @see app/Http/Controllers/BeasiswaController.php:10
 * @route '/informasi-beasiswa'
 */
    const informasiBeasiswaForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: informasiBeasiswa.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\BeasiswaController::informasiBeasiswa
 * @see app/Http/Controllers/BeasiswaController.php:10
 * @route '/informasi-beasiswa'
 */
        informasiBeasiswaForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: informasiBeasiswa.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\BeasiswaController::informasiBeasiswa
 * @see app/Http/Controllers/BeasiswaController.php:10
 * @route '/informasi-beasiswa'
 */
        informasiBeasiswaForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: informasiBeasiswa.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    informasiBeasiswa.form = informasiBeasiswaForm
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-wisuda'
 */
export const informasiWisuda = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: informasiWisuda.url(options),
    method: 'get',
})

informasiWisuda.definition = {
    methods: ["get","head"],
    url: '/informasi-wisuda',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-wisuda'
 */
informasiWisuda.url = (options?: RouteQueryOptions) => {
    return informasiWisuda.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-wisuda'
 */
informasiWisuda.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: informasiWisuda.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-wisuda'
 */
informasiWisuda.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: informasiWisuda.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-wisuda'
 */
    const informasiWisudaForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: informasiWisuda.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-wisuda'
 */
        informasiWisudaForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: informasiWisuda.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-wisuda'
 */
        informasiWisudaForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: informasiWisuda.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    informasiWisuda.form = informasiWisudaForm
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-alumni'
 */
export const informasiAlumni = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: informasiAlumni.url(options),
    method: 'get',
})

informasiAlumni.definition = {
    methods: ["get","head"],
    url: '/informasi-alumni',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-alumni'
 */
informasiAlumni.url = (options?: RouteQueryOptions) => {
    return informasiAlumni.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-alumni'
 */
informasiAlumni.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: informasiAlumni.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-alumni'
 */
informasiAlumni.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: informasiAlumni.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-alumni'
 */
    const informasiAlumniForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: informasiAlumni.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-alumni'
 */
        informasiAlumniForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: informasiAlumni.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-alumni'
 */
        informasiAlumniForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: informasiAlumni.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    informasiAlumni.form = informasiAlumniForm
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-magang'
 */
export const informasiMagang = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: informasiMagang.url(options),
    method: 'get',
})

informasiMagang.definition = {
    methods: ["get","head"],
    url: '/informasi-magang',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-magang'
 */
informasiMagang.url = (options?: RouteQueryOptions) => {
    return informasiMagang.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-magang'
 */
informasiMagang.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: informasiMagang.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-magang'
 */
informasiMagang.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: informasiMagang.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-magang'
 */
    const informasiMagangForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: informasiMagang.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-magang'
 */
        informasiMagangForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: informasiMagang.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-magang'
 */
        informasiMagangForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: informasiMagang.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    informasiMagang.form = informasiMagangForm
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-kegiatan'
 */
export const informasiKegiatan = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: informasiKegiatan.url(options),
    method: 'get',
})

informasiKegiatan.definition = {
    methods: ["get","head"],
    url: '/informasi-kegiatan',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-kegiatan'
 */
informasiKegiatan.url = (options?: RouteQueryOptions) => {
    return informasiKegiatan.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-kegiatan'
 */
informasiKegiatan.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: informasiKegiatan.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-kegiatan'
 */
informasiKegiatan.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: informasiKegiatan.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-kegiatan'
 */
    const informasiKegiatanForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: informasiKegiatan.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-kegiatan'
 */
        informasiKegiatanForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: informasiKegiatan.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-kegiatan'
 */
        informasiKegiatanForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: informasiKegiatan.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    informasiKegiatan.form = informasiKegiatanForm