<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InformasiKegiatan extends Model
{
    use HasFactory;

    protected $table = 'informasi_kegiatan';
    public $timestamps = false;
    public $incrementing = false;

    protected $fillable = [
        'id',
        'waktu_pelaksanaan',
        'lokasi',
        'penyelenggara',
    ];

    public function informasi()
    {
        return $this->belongsTo(Informasi::class, 'id', 'id');
    }
}
