import HomeController from './HomeController'
import BirdeptController from './BirdeptController'
import FaqController from './FaqController'
import InformasiController from './InformasiController'
import BeasiswaController from './BeasiswaController'
const Controllers = {
    HomeController: Object.assign(HomeController, HomeController),
BirdeptController: Object.assign(BirdeptController, BirdeptController),
FaqController: Object.assign(FaqController, FaqController),
InformasiController: Object.assign(InformasiController, InformasiController),
BeasiswaController: Object.assign(BeasiswaController, BeasiswaController),
}

export default Controllers