import { Head, Link } from '@inertiajs/react';
import React from 'react';
import AppLayout from '@/Layouts/AppLayout';

type BeasiswaDetail = {
    penyelenggara: string | null;
    tanggal_buka: string | null;
    tanggal_tutup: string | null;
    link_pendaftaran: string | null;
    syarat_beasiswa: { id: number; nama_syarat: string; keterangan: string }[];
    benefit_beasiswa: { id: number; nama_benefit: string; keterangan: string }[];
};

type Informasi = {
    id: number;
    judul: string;
    deskripsi: string;
    sumber: string | null;
    jenis_informasi: string;
    waktu_publikasi: string;
    tanggal_kadaluarsa: string | null;
    birdept: { nama_birdept: string; nama_panggilan: string } | null;
    beasiswa: BeasiswaDetail | null;
};

export default function InformasiShow({ informasi }: { informasi: Informasi }) {
    const registrationUrl = informasi.beasiswa?.link_pendaftaran;
    const safeRegistrationUrl = registrationUrl && /^https?:\/\//i.test(registrationUrl) ? registrationUrl : null;

    return (
        <>
            <Head title={informasi.judul} />
            <main className="page min-h-screen px-5 py-28 md:px-12">
                <article className="mx-auto max-w-4xl rounded-3xl bg-[#FCF8DC] p-6 text-[#1D2B44] shadow-xl md:p-12">
                    <Link href="/" className="font-semibold underline underline-offset-4">Kembali ke beranda</Link>
                    <div className="mt-8 flex flex-wrap items-center gap-3 text-sm">
                        <span className="rounded-full bg-[#1D2B44] px-3 py-1 font-semibold text-white">{informasi.jenis_informasi}</span>
                        {informasi.birdept && <span>{informasi.birdept.nama_birdept}</span>}
                        <time dateTime={informasi.waktu_publikasi}>
                            Terbit {new Date(informasi.waktu_publikasi).toLocaleString('id-ID', { day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Jakarta' })} WIB
                        </time>
                        {informasi.tanggal_kadaluarsa && <time dateTime={informasi.tanggal_kadaluarsa}>Berlaku sampai {new Date(informasi.tanggal_kadaluarsa).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Asia/Jakarta' })}</time>}
                    </div>
                    <h1 className="mt-6 text-3xl font-bold md:text-5xl">{informasi.judul}</h1>
                    <p className="mt-7 whitespace-pre-line text-base leading-8 md:text-lg">{informasi.deskripsi}</p>
                    {informasi.sumber && <p className="mt-6 text-sm">Sumber: {informasi.sumber}</p>}

                    {informasi.beasiswa && (
                        <section className="mt-10 space-y-6 border-t border-[#1D2B44]/20 pt-8">
                            {informasi.beasiswa.penyelenggara && <p><strong>Penyelenggara:</strong> {informasi.beasiswa.penyelenggara}</p>}
                            {informasi.beasiswa.syarat_beasiswa.length > 0 && (
                                <div>
                                    <h2 className="text-xl font-bold">Persyaratan</h2>
                                    <ul className="mt-2 list-disc space-y-1 pl-6">
                                        {informasi.beasiswa.syarat_beasiswa.map((item) => <li key={item.id}>{item.nama_syarat}: {item.keterangan}</li>)}
                                    </ul>
                                </div>
                            )}
                            {informasi.beasiswa.benefit_beasiswa.length > 0 && (
                                <div>
                                    <h2 className="text-xl font-bold">Manfaat</h2>
                                    <ul className="mt-2 list-disc space-y-1 pl-6">
                                        {informasi.beasiswa.benefit_beasiswa.map((item) => <li key={item.id}>{item.nama_benefit}: {item.keterangan}</li>)}
                                    </ul>
                                </div>
                            )}
                            {safeRegistrationUrl && (
                                <a href={safeRegistrationUrl} target="_blank" rel="noopener noreferrer" className="inline-block rounded-xl bg-[#1D2B44] px-5 py-3 font-semibold text-white">
                                    Buka pendaftaran
                                </a>
                            )}
                        </section>
                    )}
                </article>
            </main>
        </>
    );
}

InformasiShow.layout = (page: React.ReactNode) => <AppLayout children={page} />;
