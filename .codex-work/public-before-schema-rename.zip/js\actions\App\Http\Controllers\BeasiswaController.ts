import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\BeasiswaController::index
 * @see app/Http/Controllers/BeasiswaController.php:10
 * @route '/informasi-beasiswa'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/informasi-beasiswa',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BeasiswaController::index
 * @see app/Http/Controllers/BeasiswaController.php:10
 * @route '/informasi-beasiswa'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BeasiswaController::index
 * @see app/Http/Controllers/BeasiswaController.php:10
 * @route '/informasi-beasiswa'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\BeasiswaController::index
 * @see app/Http/Controllers/BeasiswaController.php:10
 * @route '/informasi-beasiswa'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\BeasiswaController::index
 * @see app/Http/Controllers/BeasiswaController.php:10
 * @route '/informasi-beasiswa'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\BeasiswaController::index
 * @see app/Http/Controllers/BeasiswaController.php:10
 * @route '/informasi-beasiswa'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\BeasiswaController::index
 * @see app/Http/Controllers/BeasiswaController.php:10
 * @route '/informasi-beasiswa'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const BeasiswaController = { index }

export default BeasiswaController