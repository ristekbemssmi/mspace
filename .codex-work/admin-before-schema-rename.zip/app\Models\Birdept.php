<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Birdept extends Model
{
    use HasFactory;

    protected $table = 'birdepts';
    protected $primaryKey = 'idbirdept';

    protected $fillable = [
        'nama_birdept',
        'nama_panggilan',
        'jenis',
        'deskripsi',
        'instagram',
    ];

    public function usersBem()
    {
        return $this->hasMany(UserBem::class, 'idbirdept', 'idbirdept');
    }

    public function informasi()
    {
        return $this->hasMany(Informasi::class, 'idbirdept', 'idbirdept');
    }
}
