<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Informasi extends Model
{
    use SoftDeletes;

    public const PUBLIC_COLUMNS = [
        'id', 'idbirdept', 'slug', 'judul', 'deskripsi', 'sumber',
        'jenis_informasi', 'waktu_publikasi', 'tanggal_kadaluarsa',
    ];

    protected $table = 'informasi';

    protected $primaryKey = 'id';

    protected $fillable = [
        'idbirdept',
        'iduser',
        'judul',
        'deskripsi',
        'sumber',
        'status',
        'jumlah_kunjungan',
        'waktu_publikasi',
        'jenis_informasi',
        'tanggal_kadaluarsa',
    ];

    protected $casts = [
        'waktu_publikasi' => 'datetime',
        'tanggal_kadaluarsa' => 'datetime',
    ];

    public function beasiswa()
    {
        return $this->hasOne(InformasiBeasiswa::class, 'id');
    }

    public function birdept()
    {
        return $this->belongsTo(Birdept::class, 'idbirdept', 'idbirdept');
    }

    public function birdepts()
    {
        return $this->belongsToMany(Birdept::class, 'informasi_birdepts', 'informasi_id', 'birdept_id', 'id', 'idbirdept');
    }

    public function proker()
    {
        return $this->hasOne(InformasiProker::class, 'id');
    }

    public function scopePublished($query)
    {
        return $query->where('status', 'published')
            ->whereNotNull('waktu_publikasi')
            ->where('waktu_publikasi', '<=', now());
    }

    public function scopeActive($query)
    {
        return $query->where(function ($q) {
            $q->whereNull('tanggal_kadaluarsa')
                ->orWhere('tanggal_kadaluarsa', '>=', now());
        });
    }
}
