<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PanitiaProker extends Model
{
    use HasFactory;

    protected $table = 'panitia_proker';
    public $timestamps = false;
    public $incrementing = false;

    protected $fillable = [
        'id_proker',
        'user_id',
        'jabatan',
        'divisi',
    ];

    public function proker()
    {
        return $this->belongsTo(InformasiProker::class, 'id_proker', 'id');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
}
