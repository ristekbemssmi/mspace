import AdminDashboardController from './AdminDashboardController'
import BirdeptController from './BirdeptController'
import UserController from './UserController'
import InformasiController from './InformasiController'
import FaqController from './FaqController'
import CsvImportController from './CsvImportController'
const Admin = {
    AdminDashboardController: Object.assign(AdminDashboardController, AdminDashboardController),
BirdeptController: Object.assign(BirdeptController, BirdeptController),
UserController: Object.assign(UserController, UserController),
InformasiController: Object.assign(InformasiController, InformasiController),
FaqController: Object.assign(FaqController, FaqController),
CsvImportController: Object.assign(CsvImportController, CsvImportController),
}

export default Admin