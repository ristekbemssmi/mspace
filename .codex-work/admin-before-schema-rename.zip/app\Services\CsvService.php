<?php

namespace App\Services;

use App\Models\BenefitBeasiswa;
use App\Models\Birdept;
use App\Models\Faq;
use App\Models\Informasi;
use App\Models\InformasiAlumni;
use App\Models\InformasiBeasiswa;
use App\Models\InformasiHimpunan;
use App\Models\InformasiKegiatan;
use App\Models\InformasiMagang;
use App\Models\InformasiProker;
use App\Models\InformasiWisuda;
use App\Models\PanitiaProker;
use App\Models\SyaratBeasiswa;
use App\Models\User;
use App\Models\UserBem;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class CsvService
{
    /**
     * Map of supported table names and their schema specifications
     */
    public static function getSupportedTables(): array
    {
        return [
            'birdepts' => [
                'label' => 'Birdept (Biro & Departemen)',
                'group' => 'Utama',
                'required' => ['nama_birdept', 'nama_panggilan', 'jenis'],
                'optional' => ['deskripsi', 'instagram'],
                'sample' => [
                    ['Advokasi dan Kesejahteraan Mahasiswa', 'Adkesma', 'departemen', 'Departemen yang membidangi adkesma', '@adkesma_bem'],
                    ['Internal dan Pengembangan', 'Internal', 'biro', 'Biro internal organisasi', '@internal_bem'],
                ],
            ],
            'users' => [
                'label' => 'Users (Pengguna Akun)',
                'group' => 'Utama',
                'required' => ['username', 'name', 'email', 'nim'],
                'optional' => ['telepon', 'prodi'],
                'sample' => [
                    ['budi_santoso', 'Budi Santoso', 'budi@example.invalid', 'G64190001', '081234567890', 'Ilmu Komputer'],
                    ['siti_aminah', 'Siti Aminah', 'siti@example.invalid', 'G64190002', '081298765432', 'Statistika dan Sains Data'],
                ],
            ],
            'users_bem' => [
                'label' => 'Anggota BEM (Keanggotaan)',
                'group' => 'Utama',
                'required' => ['id', 'idbirdept', 'jabatan'],
                'optional' => [],
                'sample' => [
                    ['1', '1', 'Ketua Departemen'],
                    ['2', '2', 'Staff Ahli'],
                ],
            ],
            'informasi' => [
                'label' => 'Informasi Utama (Artikel/Pengumuman)',
                'group' => 'Informasi',
                'required' => ['idbirdept', 'iduser', 'judul', 'deskripsi', 'jenis_informasi'],
                'optional' => ['sumber', 'status', 'waktu_publikasi', 'tanggal_kadaluarsa'],
                'sample' => [
                    ['1', '1', 'Pendaftaran Beasiswa Unggulan 2026', 'Informasi mengenai Beasiswa Unggulan Kemendikbud', 'beasiswa', 'https://beasiswa.kemdikbud.go.id', 'published', '2026-08-01 08:00:00', '2026-09-01 23:59:59'],
                    ['2', '1', 'Workshop AI & Data Science', 'Pelatihan intensif sains data untuk mahasiswa', 'kegiatan', 'BEM Mspace', 'published', '2026-08-05 09:00:00', '2026-08-10 17:00:00'],
                ],
            ],
            'informasi_beasiswa' => [
                'label' => 'Sub-Tabel Detail Beasiswa',
                'group' => 'Informasi Sub-Tabel',
                'required' => ['id', 'link_poster', 'link_instagram'],
                'optional' => ['penyelenggara', 'tanggal_buka', 'tanggal_tutup', 'link_pendaftaran'],
                'sample' => [
                    ['1', 'https://example.com/poster.jpg', 'https://instagram.com/p/12345', 'Kemendikbud', '2026-08-01', '2026-08-31', 'https://bit.ly/daftar-beasiswa'],
                ],
            ],
            'syarat_beasiswa' => [
                'label' => 'Sub-Tabel Syarat Beasiswa',
                'group' => 'Informasi Sub-Tabel',
                'required' => ['id_beasiswa', 'nama_syarat', 'keterangan'],
                'optional' => [],
                'sample' => [
                    ['1', 'Minimal IPK', '3.00'],
                    ['1', 'Semester Minimal', 'Semester 3'],
                ],
            ],
            'benefit_beasiswa' => [
                'label' => 'Sub-Tabel Benefit Beasiswa',
                'group' => 'Informasi Sub-Tabel',
                'required' => ['id_beasiswa', 'nama_benefit', 'keterangan'],
                'optional' => [],
                'sample' => [
                    ['1', 'Uang Saku', 'Rp 1.500.000 / bulan'],
                    ['1', 'Fasilitas Laptop', '1 Unit Laptop High-Spec'],
                ],
            ],
            'informasi_kegiatan' => [
                'label' => 'Sub-Tabel Detail Kegiatan',
                'group' => 'Informasi Sub-Tabel',
                'required' => ['id', 'waktu_pelaksanaan', 'lokasi', 'penyelenggara'],
                'optional' => [],
                'sample' => [
                    ['2', '2026-08-15 09:00:00', 'Aula FMIPA IPB', 'Biro Riset dan Teknologi'],
                ],
            ],
            'informasi_himpunan' => [
                'label' => 'Sub-Tabel Detail Himpunan',
                'group' => 'Informasi Sub-Tabel',
                'required' => ['id', 'nama_himpunan', 'kontak_person'],
                'optional' => [],
                'sample' => [
                    ['3', 'Halkom (Himpunan Ilmu Komputer)', '08123456789'],
                ],
            ],
            'informasi_wisuda' => [
                'label' => 'Sub-Tabel Detail Wisuda',
                'group' => 'Informasi Sub-Tabel',
                'required' => ['id', 'periode_wisuda', 'alur_pendaftaran'],
                'optional' => [],
                'sample' => [
                    ['4', 'Wisuda Tahap IV Tahun 2026', '1. Daftar SIMAK 2. Verifikasi Berkas 3. Cetak Undangan'],
                ],
            ],
            'informasi_alumni' => [
                'label' => 'Sub-Tabel Detail Alumni',
                'group' => 'Informasi Sub-Tabel',
                'required' => ['id', 'nama_alumni', 'angkatan', 'topik_sharing'],
                'optional' => [],
                'sample' => [
                    ['5', 'Ahmad Reza', '55 (2018)', 'Karier Senior Software Engineer di Startup Tech'],
                ],
            ],
            'informasi_magang' => [
                'label' => 'Sub-Tabel Detail Magang',
                'group' => 'Informasi Sub-Tabel',
                'required' => ['id', 'perusahaan', 'posisi', 'durasi'],
                'optional' => [],
                'sample' => [
                    ['6', 'PT GoTo Gojek Tokopedia', 'Data Analyst Intern', '6 Bulan'],
                ],
            ],
            'informasi_proker' => [
                'label' => 'Sub-Tabel Detail Program Kerja (Proker)',
                'group' => 'Informasi Sub-Tabel',
                'required' => ['id'],
                'optional' => ['tujuan', 'sasaran', 'waktu_mulai', 'waktu_selesai'],
                'sample' => [
                    ['7', 'Meningkatkan skill programming mahasiswa', 'Mahasiswa Ilmu Komputer & SSD', '2026-09-01', '2026-11-30'],
                ],
            ],
            'panitia_proker' => [
                'label' => 'Sub-Tabel Panitia Program Kerja',
                'group' => 'Informasi Sub-Tabel',
                'required' => ['id_proker', 'user_id', 'jabatan'],
                'optional' => ['divisi'],
                'sample' => [
                    ['7', '1', 'Ketua Pelaksana', 'Acara'],
                    ['7', '2', 'Staff Panitia', 'Humas'],
                ],
            ],
            'faqs' => [
                'label' => 'FAQ (Frequently Asked Questions)',
                'group' => 'Utama',
                'required' => ['pertanyaan', 'jawaban'],
                'optional' => ['urutan', 'is_active'],
                'sample' => [
                    ['Bagaimana cara mengajukan beasiswa di MSpace?', 'Anda dapat melihat daftar beasiswa pada menu Beasiswa dan mengklik tombol pendaftaran.', '1', '1'],
                    ['Siapa saja yang bisa menjadi anggota BEM?', 'Seluruh mahasiswa aktif FMIPA IPB sesuai kualifikasi open recruitment.', '2', '1'],
                ],
            ],
        ];
    }

    /**
     * Generate Excel Template (.xlsx) for a table
     */
    public function generateTemplateXlsx(string $tableName): string
    {
        $tables = self::getSupportedTables();
        if (!isset($tables[$tableName])) {
            throw new \InvalidArgumentException("Tabel '$tableName' tidak didukung.");
        }

        $config = $tables[$tableName];
        $headers = array_merge($config['required'], $config['optional']);

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle(substr($tableName, 0, 30));

        // Header row
        $sheet->fromArray([$headers], null, 'A1');

        // Sample rows
        if (!empty($config['sample'])) {
            $sheet->fromArray($config['sample'], null, 'A2');
        }

        $writer = new Xlsx($spreadsheet);
        ob_start();
        $writer->save('php://output');
        return ob_get_clean();
    }

    /**
     * Generate CSV Template string for a table
     */
    public function generateTemplate(string $tableName): string
    {
        $tables = self::getSupportedTables();
        if (!isset($tables[$tableName])) {
            throw new \InvalidArgumentException("Tabel '$tableName' tidak didukung.");
        }

        $config = $tables[$tableName];
        $headers = array_merge($config['required'], $config['optional']);

        $output = fopen('php://temp', 'r+');
        fputcsv($output, $headers);

        foreach ($config['sample'] as $row) {
            fputcsv($output, $row);
        }

        rewind($output);
        $csv = stream_get_contents($output);
        fclose($output);

        return $csv;
    }

    /**
     * Export table data to CSV format
     */
    public function exportCsv(string $tableName): string
    {
        $tables = self::getSupportedTables();
        if (!isset($tables[$tableName])) {
            throw new \InvalidArgumentException("Tabel '$tableName' tidak didukung.");
        }

        $columns = $tableName === 'users'
            ? ['id', 'username', 'name', 'email', 'nim', 'telepon', 'prodi', 'created_at']
            : array_merge($tables[$tableName]['required'], $tables[$tableName]['optional']);

        $records = DB::table($tableName)->select($columns)->cursor();

        $output = fopen('php://temp', 'r+');
        fputcsv($output, $columns);

        foreach ($records as $record) {
            fputcsv($output, array_map([$this, 'safeCsvCell'], (array) $record));
        }

        rewind($output);
        $csv = stream_get_contents($output);
        fclose($output);

        return $csv;
    }

    private function safeCsvCell(mixed $value): string
    {
        $cell = (string) ($value ?? '');

        // Spreadsheet programs may execute formula-like values when opening CSV files.
        return preg_match('/^\s*[=+\-@]/u', $cell) ? "'".$cell : $cell;
    }

    /**
     * Parse and import CSV or Excel (.xlsx, .xls) file content into specified table
     */
    public function importCsv(string $tableName, UploadedFile $file): array
    {
        $tables = self::getSupportedTables();
        if (!isset($tables[$tableName])) {
            return [
                'success' => false,
                'message' => "Tabel '$tableName' tidak didukung.",
                'inserted' => 0,
                'failed' => 0,
                'errors' => [],
            ];
        }

        $filePath = $file->getRealPath();

        try {
            // Load file using PhpSpreadsheet (supports .xlsx, .xls, .csv, .txt)
            $spreadsheet = IOFactory::load($filePath);
            $sheet = $spreadsheet->getActiveSheet();
            $rows = $sheet->toArray(null, true, true, false);
        } catch (\Throwable $e) {
            return [
                'success' => false,
                'message' => 'Gagal membaca file Excel/CSV: ' . $e->getMessage(),
                'inserted' => 0,
                'failed' => 0,
                'errors' => [$e->getMessage()],
            ];
        }

        if (empty($rows) || count($rows) < 1) {
            return [
                'success' => false,
                'message' => 'File Excel/CSV kosong.',
                'inserted' => 0,
                'failed' => 0,
                'errors' => [],
            ];
        }

        // Header row
        $rawHeader = array_shift($rows);
        $header = array_map(function ($h) {
            return strtolower(trim(preg_replace('/\x{FEFF}/u', '', (string) $h)));
        }, $rawHeader);

        $config = $tables[$tableName];
        $missingRequired = array_diff($config['required'], $header);

        if (!empty($missingRequired)) {
            return [
                'success' => false,
                'message' => 'Header kolom tidak sesuai. Kolom wajib yang hilang: ' . implode(', ', $missingRequired),
                'inserted' => 0,
                'failed' => 0,
                'errors' => ['Header wajib hilang: ' . implode(', ', $missingRequired)],
            ];
        }

        $rowNum = 1;
        $insertedCount = 0;
        $failedCount = 0;
        $errors = [];

        DB::beginTransaction();
        try {
            foreach ($rows as $row) {
                $rowNum++;

                // Skip completely empty rows
                $nonEmptyValues = array_filter($row, function ($v) {
                    return $v !== null && trim((string) $v) !== '';
                });

                if (empty($nonEmptyValues)) {
                    continue;
                }

                // Combine header with row values
                $data = [];
                foreach ($header as $idx => $colName) {
                    $val = isset($row[$idx]) ? trim((string) $row[$idx]) : null;
                    $data[$colName] = $val !== '' ? $val : null;
                }

                try {
                    $this->insertRow($tableName, $data);
                    $insertedCount++;
                } catch (\Throwable $e) {
                    $failedCount++;
                    $errors[] = "Baris $rowNum: " . $e->getMessage();
                }
            }

            DB::commit();
        } catch (\Throwable $e) {
            DB::rollBack();
            return [
                'success' => false,
                'message' => 'Gagal mengimpor file: ' . $e->getMessage(),
                'inserted' => 0,
                'failed' => $failedCount,
                'errors' => array_merge($errors, [$e->getMessage()]),
            ];
        }

        return [
            'success' => true,
            'message' => "Berhasil mengimpor $insertedCount data ke tabel $tableName." . ($failedCount > 0 ? " ($failedCount gagal)" : ''),
            'inserted' => $insertedCount,
            'failed' => $failedCount,
            'errors' => $errors,
        ];
    }

    /**
     * Insert single row into database based on table schema
     */
    protected function insertRow(string $tableName, array $data): void
    {
        switch ($tableName) {
            case 'birdepts':
                Birdept::create([
                    'nama_birdept' => $data['nama_birdept'],
                    'nama_panggilan' => $data['nama_panggilan'],
                    'jenis' => strtolower($data['jenis']),
                    'deskripsi' => $data['deskripsi'] ?? null,
                    'instagram' => $data['instagram'] ?? null,
                ]);
                break;

            case 'users':
                User::create([
                    'username' => $data['username'],
                    'name' => $data['name'],
                    'email' => $data['email'],
                    'nim' => $data['nim'],
                    // Imported users must use the password reset flow before logging in.
                    'password' => Hash::make(Str::random(64)),
                    'telepon' => $data['telepon'] ?? null,
                    'prodi' => !empty($data['prodi']) ? $data['prodi'] : null,
                ]);
                break;

            case 'users_bem':
                UserBem::updateOrCreate(
                    ['id' => $data['id']],
                    [
                        'idbirdept' => $data['idbirdept'],
                        'jabatan' => $data['jabatan'],
                    ]
                );
                break;

            case 'informasi':
                Informasi::create([
                    'idbirdept' => $data['idbirdept'],
                    'iduser' => $data['iduser'],
                    'judul' => $data['judul'],
                    'deskripsi' => $data['deskripsi'],
                    'jenis_informasi' => strtolower($data['jenis_informasi']),
                    'sumber' => $data['sumber'] ?? null,
                    'status' => strtolower($data['status'] ?? 'published'),
                    'waktu_publikasi' => !empty($data['waktu_publikasi']) ? $data['waktu_publikasi'] : now(),
                    'tanggal_kadaluarsa' => !empty($data['tanggal_kadaluarsa']) ? $data['tanggal_kadaluarsa'] : null,
                ]);
                break;

            case 'informasi_beasiswa':
                InformasiBeasiswa::updateOrCreate(
                    ['id' => $data['id']],
                    [
                        'penyelenggara' => $data['penyelenggara'] ?? null,
                        'tanggal_buka' => !empty($data['tanggal_buka']) ? $data['tanggal_buka'] : null,
                        'tanggal_tutup' => !empty($data['tanggal_tutup']) ? $data['tanggal_tutup'] : null,
                        'link_poster' => $data['link_poster'] ?? '',
                        'link_instagram' => $data['link_instagram'] ?? '',
                        'link_pendaftaran' => $data['link_pendaftaran'] ?? null,
                    ]
                );
                break;

            case 'syarat_beasiswa':
                SyaratBeasiswa::create([
                    'id_beasiswa' => $data['id_beasiswa'],
                    'nama_syarat' => $data['nama_syarat'],
                    'keterangan' => $data['keterangan'],
                ]);
                break;

            case 'benefit_beasiswa':
                BenefitBeasiswa::create([
                    'id_beasiswa' => $data['id_beasiswa'],
                    'nama_benefit' => $data['nama_benefit'],
                    'keterangan' => $data['keterangan'],
                ]);
                break;

            case 'informasi_kegiatan':
                InformasiKegiatan::updateOrCreate(
                    ['id' => $data['id']],
                    [
                        'waktu_pelaksanaan' => $data['waktu_pelaksanaan'],
                        'lokasi' => $data['lokasi'],
                        'penyelenggara' => $data['penyelenggara'],
                    ]
                );
                break;

            case 'informasi_himpunan':
                InformasiHimpunan::updateOrCreate(
                    ['id' => $data['id']],
                    [
                        'nama_himpunan' => $data['nama_himpunan'],
                        'kontak_person' => $data['kontak_person'],
                    ]
                );
                break;

            case 'informasi_wisuda':
                InformasiWisuda::updateOrCreate(
                    ['id' => $data['id']],
                    [
                        'periode_wisuda' => $data['periode_wisuda'],
                        'alur_pendaftaran' => $data['alur_pendaftaran'],
                    ]
                );
                break;

            case 'informasi_alumni':
                InformasiAlumni::updateOrCreate(
                    ['id' => $data['id']],
                    [
                        'nama_alumni' => $data['nama_alumni'],
                        'angkatan' => $data['angkatan'],
                        'topik_sharing' => $data['topik_sharing'],
                    ]
                );
                break;

            case 'informasi_magang':
                InformasiMagang::updateOrCreate(
                    ['id' => $data['id']],
                    [
                        'perusahaan' => $data['perusahaan'],
                        'posisi' => $data['posisi'],
                        'durasi' => $data['durasi'],
                    ]
                );
                break;

            case 'informasi_proker':
                InformasiProker::updateOrCreate(
                    ['id' => $data['id']],
                    [
                        'tujuan' => $data['tujuan'] ?? null,
                        'sasaran' => $data['sasaran'] ?? null,
                        'waktu_mulai' => !empty($data['waktu_mulai']) ? $data['waktu_mulai'] : null,
                        'waktu_selesai' => !empty($data['waktu_selesai']) ? $data['waktu_selesai'] : null,
                    ]
                );
                break;

            case 'panitia_proker':
                PanitiaProker::updateOrCreate(
                    [
                        'id_proker' => $data['id_proker'],
                        'user_id' => $data['user_id'],
                    ],
                    [
                        'jabatan' => $data['jabatan'],
                        'divisi' => $data['divisi'] ?? null,
                    ]
                );
                break;

            case 'faqs':
                Faq::create([
                    'pertanyaan' => $data['pertanyaan'],
                    'jawaban' => $data['jawaban'],
                    'urutan' => isset($data['urutan']) ? (int) $data['urutan'] : 0,
                    'is_active' => isset($data['is_active']) ? (bool) $data['is_active'] : true,
                ]);
                break;
        }
    }
}
