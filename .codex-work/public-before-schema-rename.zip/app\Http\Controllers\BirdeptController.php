<?php

namespace App\Http\Controllers;

use App\Models\Birdept;
use App\Models\Informasi;
use Inertia\Inertia;
use Inertia\Response;

class BirdeptController extends Controller
{
    /**
     * Menampilkan daftar semua Biro dan Departemen
     */
    public function index(): Response
    {
        $birdepts = Birdept::query()->orderBy('idbirdept')->get(['idbirdept', 'nama_birdept', 'nama_panggilan', 'jenis', 'deskripsi', 'instagram']);

        return Inertia::render('Birdept/Index', [
            'birdepts' => $birdepts,
        ]);
    }

    /**
     * Menampilkan halaman BEM SSMI dengan data Birdept
     */
    public function bemssmi(): Response
    {
        $birdepts = Birdept::query()->orderBy('idbirdept')->get(['idbirdept', 'nama_birdept', 'nama_panggilan', 'jenis', 'deskripsi', 'instagram']);

        return Inertia::render('Bemssmi/Index', [
            'birdepts' => $birdepts,
        ]);
    }

    /**
     * Menampilkan detail satu Biro/Departemen
     */
    public function show($slug): Response
    {
        $birdept = Birdept::where('nama_panggilan', $slug)->firstOrFail(['idbirdept', 'nama_birdept', 'nama_panggilan', 'jenis', 'deskripsi', 'instagram']);
        $birdept->setRelation('informasi', Informasi::query()
            ->select(Informasi::PUBLIC_COLUMNS)
            ->where('jenis_informasi', 'proker')
            ->published()
            ->active()
            ->where(fn ($query) => $query->where('idbirdept', $birdept->idbirdept)
                ->orWhereHas('birdepts', fn ($members) => $members->whereKey($birdept->idbirdept)))
            ->orderByDesc('created_at')
            ->get());

        return Inertia::render('Birdept/Show', [
            'birdept' => $birdept,
        ]);
    }
}
