<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InformasiHimpunan extends Model
{
    use HasFactory;

    protected $table = 'informasi_himpunan';
    public $timestamps = false;
    public $incrementing = false;

    protected $fillable = [
        'id',
        'nama_himpunan',
        'kontak_person',
    ];

    public function informasi()
    {
        return $this->belongsTo(Informasi::class, 'id', 'id');
    }
}
