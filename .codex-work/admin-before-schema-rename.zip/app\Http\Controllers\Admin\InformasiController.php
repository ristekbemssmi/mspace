<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Birdept;
use App\Models\Informasi;
use App\Models\InformasiAlumni;
use App\Models\InformasiBeasiswa;
use App\Models\InformasiHimpunan;
use App\Models\InformasiKegiatan;
use App\Models\InformasiMagang;
use App\Models\InformasiProker;
use App\Models\InformasiWisuda;
use App\Models\User;
use App\Services\CsvService;
use Illuminate\Support\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Inertia\Inertia;
use Inertia\Response;

class InformasiController extends Controller
{
    protected CsvService $csvService;

    public function __construct(CsvService $csvService)
    {
        $this->csvService = $csvService;
    }

    public function index(Request $request): Response
    {
        $query = Informasi::with([
            'birdept',
            'birdepts:idbirdept,nama_birdept,nama_panggilan',
            'user:id,name,username',
            'beasiswa.syarat',
            'beasiswa.benefit',
            'kegiatan',
            'himpunan',
            'wisuda',
            'alumni',
            'magang',
            'proker',
        ]);

        if ($search = $request->input('search')) {
            $query->where(function ($q) use ($search) {
                $q->where('judul', 'like', "%{$search}%")
                    ->orWhere('deskripsi', 'like', "%{$search}%")
                    ->orWhere('sumber', 'like', "%{$search}%");
            });
        }

        if ($jenis = $request->input('jenis_informasi')) {
            $query->where('jenis_informasi', $jenis);
        }

        if ($status = $request->input('status')) {
            $query->where('status', $status);
        }

        $informasi = $query->latest()->paginate(10)->withQueryString();

        $birdepts = Birdept::select('idbirdept', 'nama_birdept', 'nama_panggilan')->orderBy('nama_birdept')->get();
        $users = $request->user()->hasAdminRole('admin')
            ? User::select('id', 'name', 'username')->orderBy('name')->get()
            : User::select('id', 'name', 'username')->whereKey($request->user()->id)->get();

        return Inertia::render('admin/informasi/index', [
            'informasi' => $informasi,
            'birdepts' => $birdepts,
            'users' => $users,
            'filters' => $request->only(['search', 'jenis_informasi', 'status']),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'idbirdept' => 'required|exists:birdepts,idbirdept',
            'birdept_ids' => 'nullable|array',
            'birdept_ids.*' => 'integer|distinct|exists:birdepts,idbirdept',
            'judul' => 'required|string',
            'deskripsi' => 'required|string',
            'jenis_informasi' => 'required|in:beasiswa,kegiatan,himpunan,wisuda,alumni,magang,proker',
            'sumber' => 'nullable|string',
            'status' => 'required|in:draft,published,archived',
            'waktu_publikasi' => 'nullable|date',
            'tanggal_kadaluarsa' => 'nullable|date',

            // Sub-type fields
            'beasiswa' => 'nullable|array',
            'kegiatan' => 'nullable|array',
            'himpunan' => 'nullable|array',
            'wisuda' => 'nullable|array',
            'alumni' => 'nullable|array',
            'magang' => 'nullable|array',
            'proker' => 'nullable|array',
        ]);

        if ($validated['status'] !== 'draft') {
            Gate::authorize('publish', Informasi::class);
        }

        $timing = $this->publicationTiming($validated);
        DB::beginTransaction();
        try {
            $info = Informasi::create([
                'idbirdept' => $validated['idbirdept'],
                'iduser' => $request->user()->id,
                'judul' => $validated['judul'],
                'deskripsi' => $validated['deskripsi'],
                'jenis_informasi' => $validated['jenis_informasi'],
                'sumber' => $validated['sumber'] ?? null,
                'status' => $validated['status'],
                ...$timing,
            ]);

            $this->saveSubTypeDetail($info, $validated);
            $this->syncProkerBirdepts($info, $validated);

            DB::commit();
            return redirect()->back()->with('success', 'Informasi berhasil dibuat.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Gagal menyimpan informasi', ['exception' => $e]);
            return redirect()->back()->withErrors(['error' => 'Gagal menyimpan informasi.']);
        }
    }

    public function update(Request $request, int $id): RedirectResponse
    {
        $info = Informasi::findOrFail($id);
        Gate::authorize('update', $info);

        $validated = $request->validate([
            'idbirdept' => 'required|exists:birdepts,idbirdept',
            'birdept_ids' => 'nullable|array',
            'birdept_ids.*' => 'integer|distinct|exists:birdepts,idbirdept',
            'judul' => 'required|string',
            'deskripsi' => 'required|string',
            'jenis_informasi' => 'required|in:beasiswa,kegiatan,himpunan,wisuda,alumni,magang,proker',
            'sumber' => 'nullable|string',
            'status' => 'required|in:draft,published,archived',
            'waktu_publikasi' => 'nullable|date',
            'tanggal_kadaluarsa' => 'nullable|date',

            // Sub-type fields
            'beasiswa' => 'nullable|array',
            'kegiatan' => 'nullable|array',
            'himpunan' => 'nullable|array',
            'wisuda' => 'nullable|array',
            'alumni' => 'nullable|array',
            'magang' => 'nullable|array',
            'proker' => 'nullable|array',
        ]);

        if ($info->status !== 'draft' || $validated['status'] !== 'draft') {
            Gate::authorize('publish', Informasi::class);
        }

        $timing = $this->publicationTiming($validated);
        DB::beginTransaction();
        try {
            $info->update([
                'idbirdept' => $validated['idbirdept'],
                'judul' => $validated['judul'],
                'deskripsi' => $validated['deskripsi'],
                'jenis_informasi' => $validated['jenis_informasi'],
                'sumber' => $validated['sumber'] ?? null,
                'status' => $validated['status'],
                ...$timing,
            ]);

            $this->saveSubTypeDetail($info, $validated);
            $this->syncProkerBirdepts($info, $validated);

            DB::commit();
            return redirect()->back()->with('success', 'Informasi berhasil diperbarui.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Gagal memperbarui informasi', ['exception' => $e]);
            return redirect()->back()->withErrors(['error' => 'Gagal memperbarui informasi.']);
        }
    }

    public function destroy(int $id): RedirectResponse
    {
        $info = Informasi::findOrFail($id);
        $info->delete();

        return redirect()->back()->with('success', 'Informasi berhasil dihapus.');
    }

    private function publicationTiming(array $data): array
    {
        $publishedAt = !empty($data['waktu_publikasi'])
            ? Carbon::parse($data['waktu_publikasi'], config('app.timezone'))
            : ($data['status'] === 'published' ? now() : null);
        $expiresAt = !empty($data['tanggal_kadaluarsa'])
            ? Carbon::parse($data['tanggal_kadaluarsa'], config('app.timezone'))->endOfDay()
            : null;

        if ($publishedAt && $expiresAt && $expiresAt->lessThan($publishedAt)) {
            throw ValidationException::withMessages([
                'tanggal_kadaluarsa' => 'Tanggal kedaluwarsa harus setelah waktu publikasi.',
            ]);
        }

        return ['waktu_publikasi' => $publishedAt, 'tanggal_kadaluarsa' => $expiresAt];
    }

    protected function saveSubTypeDetail(Informasi $info, array $data): void
    {
        switch ($info->jenis_informasi) {
            case 'beasiswa':
                if (!empty($data['beasiswa'])) {
                    $b = $data['beasiswa'];
                    InformasiBeasiswa::updateOrCreate(
                        ['id' => $info->id],
                        [
                            'penyelenggara' => $b['penyelenggara'] ?? null,
                            'tanggal_buka' => $b['tanggal_buka'] ?? null,
                            'tanggal_tutup' => $b['tanggal_tutup'] ?? null,
                            'link_poster' => $b['link_poster'] ?? '',
                            'link_instagram' => $b['link_instagram'] ?? '',
                            'link_pendaftaran' => $b['link_pendaftaran'] ?? null,
                        ]
                    );
                }
                break;

            case 'kegiatan':
                if (!empty($data['kegiatan'])) {
                    $k = $data['kegiatan'];
                    InformasiKegiatan::updateOrCreate(
                        ['id' => $info->id],
                        [
                            'waktu_pelaksanaan' => $k['waktu_pelaksanaan'] ?? now(),
                            'lokasi' => $k['lokasi'] ?? '',
                            'penyelenggara' => $k['penyelenggara'] ?? '',
                        ]
                    );
                }
                break;

            case 'himpunan':
                if (!empty($data['himpunan'])) {
                    $h = $data['himpunan'];
                    InformasiHimpunan::updateOrCreate(
                        ['id' => $info->id],
                        [
                            'nama_himpunan' => $h['nama_himpunan'] ?? '',
                            'kontak_person' => $h['kontak_person'] ?? '',
                        ]
                    );
                }
                break;

            case 'wisuda':
                if (!empty($data['wisuda'])) {
                    $w = $data['wisuda'];
                    InformasiWisuda::updateOrCreate(
                        ['id' => $info->id],
                        [
                            'periode_wisuda' => $w['periode_wisuda'] ?? '',
                            'alur_pendaftaran' => $w['alur_pendaftaran'] ?? '',
                        ]
                    );
                }
                break;

            case 'alumni':
                if (!empty($data['alumni'])) {
                    $a = $data['alumni'];
                    InformasiAlumni::updateOrCreate(
                        ['id' => $info->id],
                        [
                            'nama_alumni' => $a['nama_alumni'] ?? '',
                            'angkatan' => $a['angkatan'] ?? '',
                            'topik_sharing' => $a['topik_sharing'] ?? '',
                        ]
                    );
                }
                break;

            case 'magang':
                if (!empty($data['magang'])) {
                    $m = $data['magang'];
                    InformasiMagang::updateOrCreate(
                        ['id' => $info->id],
                        [
                            'perusahaan' => $m['perusahaan'] ?? '',
                            'posisi' => $m['posisi'] ?? '',
                            'durasi' => $m['durasi'] ?? '',
                        ]
                    );
                }
                break;

            case 'proker':
                if (!empty($data['proker'])) {
                    $p = $data['proker'];
                    InformasiProker::updateOrCreate(
                        ['id' => $info->id],
                        [
                            'tujuan' => $p['tujuan'] ?? null,
                            'sasaran' => $p['sasaran'] ?? null,
                            'waktu_mulai' => $p['waktu_mulai'] ?? null,
                            'waktu_selesai' => $p['waktu_selesai'] ?? null,
                        ]
                    );
                }
                break;
        }
    }

    private function syncProkerBirdepts(Informasi $info, array $data): void
    {
        if ($info->jenis_informasi !== 'proker') {
            $info->birdepts()->detach();

            return;
        }

        $ids = array_values(array_unique(array_filter(
            array_map('intval', $data['birdept_ids'] ?? []),
            fn (int $id) => $id !== (int) $data['idbirdept']
        )));
        $info->birdepts()->sync($ids);
    }

    public function importCsv(Request $request): RedirectResponse
    {
        $request->validate([
            'file' => 'required|file|mimes:xlsx,xls,csv,txt|max:10240',
            'target_table' => 'nullable|string',
        ]);

        $table = $request->input('target_table', 'informasi');
        $result = $this->csvService->importCsv($table, $request->file('file'));

        if (!$result['success']) {
            return redirect()->back()->withErrors(['csv' => $result['message']]);
        }

        return redirect()->back()->with('success', $result['message']);
    }

    public function downloadTemplate(Request $request): StreamedResponse
    {
        $table = $request->input('table', 'informasi');
        $csvContent = $this->csvService->generateTemplate($table);

        return response()->streamDownload(function () use ($csvContent) {
            echo $csvContent;
        }, "template_{$table}.csv", [
            'Content-Type' => 'text/csv',
        ]);
    }

    public function exportCsv(Request $request): StreamedResponse
    {
        $table = $request->input('table', 'informasi');
        $csvContent = $this->csvService->exportCsv($table);

        return response()->streamDownload(function () use ($csvContent) {
            echo $csvContent;
        }, "export_{$table}_" . date('Y-m-d_H-i-s') . '.csv', [
            'Content-Type' => 'text/csv',
        ]);
    }
}
