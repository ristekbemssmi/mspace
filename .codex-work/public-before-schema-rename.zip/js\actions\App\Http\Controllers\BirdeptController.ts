import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\BirdeptController::bemssmi
 * @see app/Http/Controllers/BirdeptController.php:27
 * @route '/bemssmi'
 */
export const bemssmi = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: bemssmi.url(options),
    method: 'get',
})

bemssmi.definition = {
    methods: ["get","head"],
    url: '/bemssmi',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BirdeptController::bemssmi
 * @see app/Http/Controllers/BirdeptController.php:27
 * @route '/bemssmi'
 */
bemssmi.url = (options?: RouteQueryOptions) => {
    return bemssmi.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BirdeptController::bemssmi
 * @see app/Http/Controllers/BirdeptController.php:27
 * @route '/bemssmi'
 */
bemssmi.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: bemssmi.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\BirdeptController::bemssmi
 * @see app/Http/Controllers/BirdeptController.php:27
 * @route '/bemssmi'
 */
bemssmi.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: bemssmi.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\BirdeptController::bemssmi
 * @see app/Http/Controllers/BirdeptController.php:27
 * @route '/bemssmi'
 */
    const bemssmiForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: bemssmi.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\BirdeptController::bemssmi
 * @see app/Http/Controllers/BirdeptController.php:27
 * @route '/bemssmi'
 */
        bemssmiForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: bemssmi.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\BirdeptController::bemssmi
 * @see app/Http/Controllers/BirdeptController.php:27
 * @route '/bemssmi'
 */
        bemssmiForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: bemssmi.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    bemssmi.form = bemssmiForm
/**
* @see \App\Http\Controllers\BirdeptController::show
 * @see app/Http/Controllers/BirdeptController.php:39
 * @route '/birdept/{slug}'
 */
export const show = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/birdept/{slug}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BirdeptController::show
 * @see app/Http/Controllers/BirdeptController.php:39
 * @route '/birdept/{slug}'
 */
show.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return show.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BirdeptController::show
 * @see app/Http/Controllers/BirdeptController.php:39
 * @route '/birdept/{slug}'
 */
show.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\BirdeptController::show
 * @see app/Http/Controllers/BirdeptController.php:39
 * @route '/birdept/{slug}'
 */
show.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\BirdeptController::show
 * @see app/Http/Controllers/BirdeptController.php:39
 * @route '/birdept/{slug}'
 */
    const showForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\BirdeptController::show
 * @see app/Http/Controllers/BirdeptController.php:39
 * @route '/birdept/{slug}'
 */
        showForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\BirdeptController::show
 * @see app/Http/Controllers/BirdeptController.php:39
 * @route '/birdept/{slug}'
 */
        showForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const BirdeptController = { bemssmi, show }

export default BirdeptController