<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Informasi extends Model
{
    use HasFactory;

    protected $table = 'informasi';

    protected $fillable = [
        'idbirdept',
        'iduser',
        'judul',
        'deskripsi',
        'sumber',
        'status',
        'jumlah_kunjungan',
        'waktu_publikasi',
        'jenis_informasi',
        'tanggal_kadaluarsa',
    ];

    protected function casts(): array
    {
        return [
            'waktu_publikasi' => 'datetime',
            'tanggal_kadaluarsa' => 'datetime',
            'jumlah_kunjungan' => 'integer',
        ];
    }

    public function birdept()
    {
        return $this->belongsTo(Birdept::class, 'idbirdept', 'idbirdept');
    }

    public function birdepts()
    {
        return $this->belongsToMany(Birdept::class, 'informasi_birdepts', 'informasi_id', 'birdept_id', 'id', 'idbirdept');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'iduser', 'id');
    }

    public function beasiswa()
    {
        return $this->hasOne(InformasiBeasiswa::class, 'id', 'id');
    }

    public function kegiatan()
    {
        return $this->hasOne(InformasiKegiatan::class, 'id', 'id');
    }

    public function himpunan()
    {
        return $this->hasOne(InformasiHimpunan::class, 'id', 'id');
    }

    public function wisuda()
    {
        return $this->hasOne(InformasiWisuda::class, 'id', 'id');
    }

    public function alumni()
    {
        return $this->hasOne(InformasiAlumni::class, 'id', 'id');
    }

    public function magang()
    {
        return $this->hasOne(InformasiMagang::class, 'id', 'id');
    }

    public function proker()
    {
        return $this->hasOne(InformasiProker::class, 'id', 'id');
    }
}
