import { Head, router, useForm } from '@inertiajs/react';
import { Download, Edit2, Megaphone, Plus, Search, Trash2 } from 'lucide-react';
import React, { useState } from 'react';
import { CsvUploadModal } from '@/components/csv-upload-modal';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import AppLayout from '@/layouts/app-layout';
import type { BreadcrumbItem } from '@/types';

interface BirdeptOption {
    idbirdept: number;
    nama_birdept: string;
    nama_panggilan: string;
}

interface UserOption {
    id: number;
    name: string;
    username: string;
}

interface InformasiItem {
    id: number;
    idbirdept: number;
    iduser: number;
    judul: string;
    deskripsi: string;
    sumber?: string;
    status: 'draft' | 'published' | 'archived';
    jumlah_kunjungan: number;
    waktu_publikasi?: string;
    jenis_informasi: 'beasiswa' | 'kegiatan' | 'himpunan' | 'wisuda' | 'alumni' | 'magang' | 'proker';
    tanggal_kadaluarsa?: string;
    birdept?: BirdeptOption;
    birdepts?: BirdeptOption[];
    user?: UserOption;
    beasiswa?: any;
    kegiatan?: any;
    himpunan?: any;
    wisuda?: any;
    alumni?: any;
    magang?: any;
    proker?: any;
}

interface PaginatedInformasi {
    data: InformasiItem[];
    current_page: number;
    last_page: number;
    total: number;
}

interface Props {
    informasi: PaginatedInformasi;
    birdepts: BirdeptOption[];
    users: UserOption[];
    filters: { search?: string; jenis_informasi?: string; status?: string };
}

const breadcrumbs: BreadcrumbItem[] = [
    { title: 'Dashboard', href: '/admin/dashboard' },
    { title: 'Informasi & Beasiswa', href: '/admin/informasi' },
];

const JENIS_INFORMASI_LIST = [
    { value: 'beasiswa', label: 'Beasiswa' },
    { value: 'kegiatan', label: 'Kegiatan' },
    { value: 'himpunan', label: 'Himpunan' },
    { value: 'wisuda', label: 'Wisuda' },
    { value: 'alumni', label: 'Alumni' },
    { value: 'magang', label: 'Magang' },
    { value: 'proker', label: 'Proker' },
];

export default function InformasiIndex({ informasi, birdepts, users, filters }: Props) {
    const [search, setSearch] = useState(filters.search || '');
    const [jenisFilter, setJenisFilter] = useState(filters.jenis_informasi || '');
    const [statusFilter, setStatusFilter] = useState(filters.status || '');
    const [isCreateOpen, setIsCreateOpen] = useState(false);
    const [editingInfo, setEditingInfo] = useState<InformasiItem | null>(null);

    const { data, setData, post, put, processing, errors, reset, clearErrors } = useForm({
        idbirdept: birdepts.length > 0 ? birdepts[0].idbirdept : 0,
        birdept_ids: [] as number[],
        iduser: users.length > 0 ? users[0].id : 0,
        judul: '',
        deskripsi: '',
        sumber: '',
        status: 'published' as 'draft' | 'published' | 'archived',
        waktu_publikasi: '',
        tanggal_kadaluarsa: '',
        jenis_informasi: 'beasiswa' as 'beasiswa' | 'kegiatan' | 'himpunan' | 'wisuda' | 'alumni' | 'magang' | 'proker',

        // Sub-Type Payload
        beasiswa: { penyelenggara: '', tanggal_buka: '', tanggal_tutup: '', link_poster: '', link_instagram: '', link_pendaftaran: '' },
        kegiatan: { waktu_pelaksanaan: '', lokasi: '', penyelenggara: '' },
        himpunan: { nama_himpunan: '', kontak_person: '' },
        wisuda: { periode_wisuda: '', alur_pendaftaran: '' },
        alumni: { nama_alumni: '', angkatan: '', topik_sharing: '' },
        magang: { perusahaan: '', posisi: '', durasi: '' },
        proker: { tujuan: '', sasaran: '', waktu_mulai: '', waktu_selesai: '' },
    });

    const handleSearch = (e: React.FormEvent) => {
        e.preventDefault();
        router.get('/admin/informasi', { search, jenis_informasi: jenisFilter, status: statusFilter }, { preserveState: true });
    };

    const handleJenisTabClick = (val: string) => {
        const nextVal = jenisFilter === val ? '' : val;
        setJenisFilter(nextVal);
        router.get('/admin/informasi', { search, jenis_informasi: nextVal, status: statusFilter }, { preserveState: true });
    };

    const openCreateModal = () => {
        reset();
        clearErrors();
        setEditingInfo(null);
        setIsCreateOpen(true);
    };

    const openEditModal = (item: InformasiItem) => {
        clearErrors();
        setEditingInfo(item);
        setData({
            idbirdept: item.idbirdept,
            birdept_ids: item.jenis_informasi === 'proker'
                ? (item.birdepts || []).map((birdept) => birdept.idbirdept)
                : [],
            iduser: item.iduser,
            judul: item.judul,
            deskripsi: item.deskripsi,
            sumber: item.sumber || '',
            status: item.status,
            waktu_publikasi: item.waktu_publikasi ? item.waktu_publikasi.replace(' ', 'T').substring(0, 16) : '',
            tanggal_kadaluarsa: item.tanggal_kadaluarsa ? item.tanggal_kadaluarsa.substring(0, 10) : '',
            jenis_informasi: item.jenis_informasi,

            beasiswa: item.beasiswa || { penyelenggara: '', tanggal_buka: '', tanggal_tutup: '', link_poster: '', link_instagram: '', link_pendaftaran: '' },
            kegiatan: item.kegiatan || { waktu_pelaksanaan: '', lokasi: '', penyelenggara: '' },
            himpunan: item.himpunan || { nama_himpunan: '', kontak_person: '' },
            wisuda: item.wisuda || { periode_wisuda: '', alur_pendaftaran: '' },
            alumni: item.alumni || { nama_alumni: '', angkatan: '', topik_sharing: '' },
            magang: item.magang || { perusahaan: '', posisi: '', durasi: '' },
            proker: item.proker || { tujuan: '', sasaran: '', waktu_mulai: '', waktu_selesai: '' },
        });
        setIsCreateOpen(true);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();

        if (editingInfo) {
            put(`/admin/informasi/${editingInfo.id}`, {
                onSuccess: () => {
                    setIsCreateOpen(false);
                    reset();
                },
            });
        } else {
            post('/admin/informasi', {
                onSuccess: () => {
                    setIsCreateOpen(false);
                    reset();
                },
            });
        }
    };

    const handleDelete = (id: number) => {
        if (confirm('Apakah Anda yakin ingin menghapus data Informasi ini?')) {
            router.delete(`/admin/informasi/${id}`);
        }
    };

    return (
        <AppLayout breadcrumbs={breadcrumbs}>
            <Head title="Informasi & Beasiswa - MSPACE Admin" />

            <div className="flex flex-1 flex-col gap-6 p-4 md:p-6 bg-transparent">
                {/* Header Title */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                        <h1 className="text-2xl font-black tracking-tight flex items-center gap-2">
                            <Megaphone className="h-7 w-7 text-amber-500" />
                            Manajemen Informasi, Beasiswa & Kegiatan
                        </h1>
                        <p className="text-sm text-muted-foreground mt-1">
                            Kelola konten publik Beasiswa, Kegiatan, Himpunan, Wisuda, Alumni, Magang, dan Proker.
                        </p>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                        <CsvUploadModal
                            title="Upload CSV Informasi"
                            description="Pilih target tabel informasi atau tabel detail yang ingin diimpor sekaligus."
                            uploadUrl="/admin/informasi/import-csv"
                            templateUrl="/admin/informasi/template-csv"
                            exportUrl="/admin/informasi/export-csv"
                            tableOptions={[
                                { value: 'informasi', label: 'Tabel Informasi Utama' },
                                { value: 'informasi_beasiswa', label: 'Sub-Tabel Detail Beasiswa' },
                                { value: 'syarat_beasiswa', label: 'Sub-Tabel Syarat Beasiswa' },
                                { value: 'benefit_beasiswa', label: 'Sub-Tabel Benefit Beasiswa' },
                                { value: 'informasi_kegiatan', label: 'Sub-Tabel Detail Kegiatan' },
                                { value: 'informasi_himpunan', label: 'Sub-Tabel Detail Himpunan' },
                                { value: 'informasi_wisuda', label: 'Sub-Tabel Detail Wisuda' },
                                { value: 'informasi_alumni', label: 'Sub-Tabel Detail Alumni' },
                                { value: 'informasi_magang', label: 'Sub-Tabel Detail Magang' },
                                { value: 'informasi_proker', label: 'Sub-Tabel Detail Proker (Program Kerja)' },
                                { value: 'panitia_proker', label: 'Sub-Tabel Panitia Program Kerja' },
                            ]}
                        />

                        <a href="/admin/informasi/export-csv" download>
                            <Button variant="outline" size="sm" className="gap-1 text-xs">
                                <Download className="h-3.5 w-3.5" />
                                Export CSV
                            </Button>
                        </a>

                        <Button onClick={openCreateModal} className="bg-amber-600 hover:bg-amber-700 text-white gap-2">
                            <Plus className="h-4 w-4" />
                            Tambah Informasi
                        </Button>
                    </div>
                </div>

                {/* Jenis Informasi Tabs */}
                <div className="flex items-center gap-2 overflow-x-auto pb-1">
                    <Button
                        variant={jenisFilter === '' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => handleJenisTabClick('')}
                        className="rounded-full text-xs font-semibold"
                    >
                        Semua Jenis
                    </Button>
                    {JENIS_INFORMASI_LIST.map((tab) => (
                        <Button
                            key={tab.value}
                            variant={jenisFilter === tab.value ? 'default' : 'outline'}
                            size="sm"
                            onClick={() => handleJenisTabClick(tab.value)}
                            className="rounded-full text-xs font-semibold capitalize"
                        >
                            {tab.label}
                        </Button>
                    ))}
                </div>

                {/* Search & Filter */}
                <Card className="shadow-sm">
                    <CardContent className="p-4">
                        <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-3">
                            <div className="relative flex-1">
                                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                                <Input
                                    type="text"
                                    placeholder="Cari judul, deskripsi, atau sumber..."
                                    value={search}
                                    onChange={(e) => setSearch(e.target.value)}
                                    className="pl-9 text-sm"
                                />
                            </div>
                            <select
                                value={statusFilter}
                                onChange={(e) => setStatusFilter(e.target.value)}
                                className="rounded-md border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                            >
                                <option value="">Semua Status</option>
                                <option value="published">Published</option>
                                <option value="draft">Draft</option>
                                <option value="archived">Archived</option>
                            </select>
                            <Button type="submit" variant="secondary" className="text-sm">
                                Cari
                            </Button>
                        </form>
                    </CardContent>
                </Card>

                {/* Table Card */}
                <Card className="shadow-sm">
                    <CardHeader className="py-4 border-b">
                        <CardTitle className="text-base font-bold flex items-center justify-between">
                            <span>Daftar Informasi ({informasi.total})</span>
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="p-0">
                        <div className="overflow-x-auto">
                            <table className="w-full text-left text-sm">
                                <thead className="bg-muted/50 text-xs uppercase font-semibold text-muted-foreground border-b">
                                    <tr>
                                        <th className="px-4 py-3">Judul & Jenis</th>
                                        <th className="px-4 py-3">Penerbit (Birdept)</th>
                                        <th className="px-4 py-3">Status</th>
                                        <th className="px-4 py-3">Waktu Publikasi</th>
                                        <th className="px-4 py-3">Kunjungan</th>
                                        <th className="px-4 py-3 text-right">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y">
                                    {informasi.data.length === 0 ? (
                                        <tr>
                                            <td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">
                                                Tidak ada data informasi ditemukan.
                                            </td>
                                        </tr>
                                    ) : (
                                        informasi.data.map((item) => (
                                            <tr key={item.id} className="hover:bg-muted/30 transition">
                                                <td className="px-4 py-3">
                                                    <p className="font-bold text-foreground leading-snug">{item.judul}</p>
                                                    <div className="flex items-center gap-2 mt-1">
                                                        <Badge variant="outline" className="capitalize text-[10px]">
                                                            {item.jenis_informasi}
                                                        </Badge>
                                                        {item.sumber && <span className="text-xs text-muted-foreground truncate max-w-[200px]">{item.sumber}</span>}
                                                    </div>
                                                </td>
                                                <td className="px-4 py-3 text-xs">
                                                    <p className="font-semibold text-foreground">{item.jenis_informasi === 'proker' && item.birdepts?.length
                                                        ? [item.birdept?.nama_panggilan, ...item.birdepts.map((birdept) => birdept.nama_panggilan)].filter(Boolean).join(' + ')
                                                        : item.birdept?.nama_panggilan || 'Birdept'}</p>
                                                    <p className="text-muted-foreground">Oleh @{item.user?.username || 'admin'}</p>
                                                </td>
                                                <td className="px-4 py-3">
                                                    <Badge
                                                        className={
                                                            item.status === 'published'
                                                                ? 'bg-emerald-600 text-white'
                                                                : item.status === 'draft'
                                                                ? 'bg-amber-600 text-white'
                                                                : 'bg-slate-600 text-white'
                                                        }
                                                    >
                                                        {item.status.toUpperCase()}
                                                    </Badge>
                                                </td>
                                                <td className="px-4 py-3 text-xs text-muted-foreground">
                                                    {item.waktu_publikasi ? new Date(item.waktu_publikasi).toLocaleDateString('id-ID') : '-'}
                                                </td>
                                                <td className="px-4 py-3 text-xs font-mono font-medium">
                                                    {item.jumlah_kunjungan} views
                                                </td>
                                                <td className="px-4 py-3 text-right space-x-2">
                                                    <Button
                                                        variant="ghost"
                                                        size="sm"
                                                        onClick={() => openEditModal(item)}
                                                        className="h-8 w-8 p-0 text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                                                    >
                                                        <Edit2 className="h-4 w-4" />
                                                    </Button>
                                                    <Button
                                                        variant="ghost"
                                                        size="sm"
                                                        onClick={() => handleDelete(item.id)}
                                                        className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                                                    >
                                                        <Trash2 className="h-4 w-4" />
                                                    </Button>
                                                </td>
                                            </tr>
                                        ))
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </CardContent>
                </Card>

                {/* Create / Edit Form Modal */}
                <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
                    <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
                        <DialogHeader>
                            <DialogTitle className="font-bold text-xl">
                                {editingInfo ? 'Edit Informasi' : 'Tambah Informasi Baru'}
                            </DialogTitle>
                            <DialogDescription>
                                Masukkan rincian artikel informasi dan pilih tipe spesifiknya.
                            </DialogDescription>
                        </DialogHeader>

                        <form onSubmit={handleSubmit} className="space-y-4 py-2">
                            <div className="space-y-1.5">
                                <Label htmlFor="judul">Judul Informasi</Label>
                                <Input
                                    id="judul"
                                    placeholder="Contoh: Pendaftaran Beasiswa MSPACE 2026"
                                    value={data.judul}
                                    onChange={(e) => setData('judul', e.target.value)}
                                />
                                {errors.judul && <p className="text-xs text-red-500">{errors.judul}</p>}
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-1.5">
                                    <Label htmlFor="jenis_informasi">Jenis Informasi</Label>
                                    <select
                                        id="jenis_informasi"
                                        value={data.jenis_informasi}
                                        onChange={(e) => setData('jenis_informasi', e.target.value as any)}
                                        className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                                    >
                                        {JENIS_INFORMASI_LIST.map((opt) => (
                                            <option key={opt.value} value={opt.value}>
                                                {opt.label}
                                            </option>
                                        ))}
                                    </select>
                                    {errors.jenis_informasi && <p className="text-xs text-red-500">{errors.jenis_informasi}</p>}
                                </div>

                                <div className="space-y-1.5">
                                    <Label htmlFor="status">Status Publikasi</Label>
                                    <select
                                        id="status"
                                        value={data.status}
                                        onChange={(e) => setData('status', e.target.value as any)}
                                        className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                                    >
                                        <option value="published">Published</option>
                                        <option value="draft">Draft</option>
                                        <option value="archived">Archived</option>
                                    </select>
                                    {errors.status && <p className="text-xs text-red-500">{errors.status}</p>}
                                </div>
                            </div>

                            <div className="grid gap-4 sm:grid-cols-2">
                                <div className="space-y-1.5">
                                    <Label htmlFor="waktu_publikasi">Waktu publikasi</Label>
                                    <Input id="waktu_publikasi" type="datetime-local" value={data.waktu_publikasi} onChange={(e) => setData('waktu_publikasi', e.target.value)} />
                                    <p className="text-xs text-white/70">Kosongkan untuk terbit sekarang saat status Published.</p>
                                    {errors.waktu_publikasi && <p className="text-xs text-red-300">{errors.waktu_publikasi}</p>}
                                </div>
                                <div className="space-y-1.5">
                                    <Label htmlFor="tanggal_kadaluarsa">Tanggal kedaluwarsa</Label>
                                    <Input id="tanggal_kadaluarsa" type="date" value={data.tanggal_kadaluarsa} onChange={(e) => setData('tanggal_kadaluarsa', e.target.value)} />
                                    <p className="text-xs text-white/70">Informasi tetap tampil sampai akhir tanggal ini.</p>
                                    {errors.tanggal_kadaluarsa && <p className="text-xs text-red-300">{errors.tanggal_kadaluarsa}</p>}
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-1.5">
                                    <Label htmlFor="idbirdept">{data.jenis_informasi === 'proker' ? 'Biro / Departemen Utama' : 'Biro / Departemen Penanggung Jawab'}</Label>
                                    <select
                                        id="idbirdept"
                                        value={data.idbirdept}
                                        onChange={(e) => setData('idbirdept', Number(e.target.value))}
                                        className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                                    >
                                        {birdepts.map((b) => (
                                            <option key={b.idbirdept} value={b.idbirdept}>
                                                {b.nama_panggilan} ({b.nama_birdept})
                                            </option>
                                        ))}
                                    </select>
                                    {errors.idbirdept && <p className="text-xs text-red-500">{errors.idbirdept}</p>}
                                </div>

                                <div className="space-y-1.5">
                                    <Label htmlFor="iduser">User Pembuat</Label>
                                    <select
                                        id="iduser"
                                        value={data.iduser}
                                        onChange={(e) => setData('iduser', Number(e.target.value))}
                                        className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                                    >
                                        {users.map((u) => (
                                            <option key={u.id} value={u.id}>
                                                {u.name} (@{u.username})
                                            </option>
                                        ))}
                                    </select>
                                    {errors.iduser && <p className="text-xs text-red-500">{errors.iduser}</p>}
                                </div>
                            </div>

                            {data.jenis_informasi === 'proker' && (
                                <fieldset className="rounded-xl border border-[#607397] p-4">
                                    <legend className="px-2 text-sm font-bold text-[#f4e06d]">Birdept kolaborator</legend>
                                    <p className="mb-3 text-xs text-white/75">Pilih biro atau departemen lain yang ikut menangani proker ini. Birdept utama selalu tercatat.</p>
                                    <div className="grid gap-2 sm:grid-cols-2">
                                        {birdepts.filter((birdept) => birdept.idbirdept !== data.idbirdept).map((birdept) => (
                                            <label key={birdept.idbirdept} className="flex cursor-pointer items-center gap-3 rounded-lg border border-white/15 bg-white/5 px-3 py-2 text-sm text-white hover:bg-white/10">
                                                <input type="checkbox" className="accent-[#f4e06d]" checked={data.birdept_ids.includes(birdept.idbirdept)} onChange={(event) => setData('birdept_ids', event.target.checked
                                                    ? [...data.birdept_ids, birdept.idbirdept]
                                                    : data.birdept_ids.filter((id) => id !== birdept.idbirdept))} />
                                                <span>{birdept.nama_panggilan} ({birdept.nama_birdept})</span>
                                            </label>
                                        ))}
                                    </div>
                                    {errors.birdept_ids && <p className="mt-2 text-xs text-red-300">{errors.birdept_ids}</p>}
                                </fieldset>
                            )}

                            <div className="space-y-1.5">
                                <Label htmlFor="sumber">Sumber Informasi (Link / Institusi)</Label>
                                <Input
                                    id="sumber"
                                    placeholder="https://..."
                                    value={data.sumber}
                                    onChange={(e) => setData('sumber', e.target.value)}
                                />
                                {errors.sumber && <p className="text-xs text-red-500">{errors.sumber}</p>}
                            </div>

                            <div className="space-y-1.5">
                                <Label htmlFor="deskripsi">Deskripsi / Isi Informasi</Label>
                                <textarea
                                    id="deskripsi"
                                    rows={4}
                                    placeholder="Tuliskan isi informasi secara lengkap..."
                                    value={data.deskripsi}
                                    onChange={(e) => setData('deskripsi', e.target.value)}
                                    className="w-full rounded-md border border-input bg-background p-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                                />
                                {errors.deskripsi && <p className="text-xs text-red-500">{errors.deskripsi}</p>}
                            </div>

                            {/* Dynamic Sub-Type Form Fields */}
                            {data.jenis_informasi === 'beasiswa' && (
                                <div className="rounded-xl border p-4 bg-amber-50/40 dark:bg-amber-950/20 space-y-3">
                                    <h4 className="font-bold text-sm text-amber-800 dark:text-amber-300">Rincian Detail Beasiswa</h4>
                                    <div className="grid grid-cols-2 gap-3 text-xs">
                                        <div>
                                            <Label>Penyelenggara</Label>
                                            <Input
                                                placeholder="Kemendikbud"
                                                value={data.beasiswa?.penyelenggara || ''}
                                                onChange={(e) => setData('beasiswa', { ...data.beasiswa, penyelenggara: e.target.value })}
                                            />
                                        </div>
                                        <div>
                                            <Label>Link Pendaftaran</Label>
                                            <Input
                                                placeholder="https://bit.ly/daftar"
                                                value={data.beasiswa?.link_pendaftaran || ''}
                                                onChange={(e) => setData('beasiswa', { ...data.beasiswa, link_pendaftaran: e.target.value })}
                                            />
                                        </div>
                                        <div>
                                            <Label>Link Poster</Label>
                                            <Input
                                                placeholder="https://..."
                                                value={data.beasiswa?.link_poster || ''}
                                                onChange={(e) => setData('beasiswa', { ...data.beasiswa, link_poster: e.target.value })}
                                            />
                                        </div>
                                        <div>
                                            <Label>Link Instagram</Label>
                                            <Input
                                                placeholder="https://..."
                                                value={data.beasiswa?.link_instagram || ''}
                                                onChange={(e) => setData('beasiswa', { ...data.beasiswa, link_instagram: e.target.value })}
                                            />
                                        </div>
                                    </div>
                                </div>
                            )}

                            {data.jenis_informasi === 'kegiatan' && (
                                <div className="rounded-xl border p-4 bg-blue-50/40 dark:bg-blue-950/20 space-y-3">
                                    <h4 className="font-bold text-sm text-blue-800 dark:text-blue-300">Rincian Detail Kegiatan</h4>
                                    <div className="grid grid-cols-2 gap-3 text-xs">
                                        <div>
                                            <Label>Lokasi</Label>
                                            <Input
                                                placeholder="Aula FMIPA IPB"
                                                value={data.kegiatan?.lokasi || ''}
                                                onChange={(e) => setData('kegiatan', { ...data.kegiatan, lokasi: e.target.value })}
                                            />
                                        </div>
                                        <div>
                                            <Label>Penyelenggara</Label>
                                            <Input
                                                placeholder="Biro Riset & Teknologi"
                                                value={data.kegiatan?.penyelenggara || ''}
                                                onChange={(e) => setData('kegiatan', { ...data.kegiatan, penyelenggara: e.target.value })}
                                            />
                                        </div>
                                    </div>
                                </div>
                            )}

                            <div className="flex justify-end gap-3 pt-3">
                                <Button type="button" variant="outline" onClick={() => setIsCreateOpen(false)}>
                                    Batal
                                </Button>
                                <Button type="submit" disabled={processing} className="bg-amber-600 hover:bg-amber-700 text-white">
                                    {editingInfo ? 'Simpan Perubahan' : 'Tambah Informasi'}
                                </Button>
                            </div>
                        </form>
                    </DialogContent>
                </Dialog>
            </div>
        </AppLayout>
    );
}
