<?php

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;

uses(RefreshDatabase::class);

test('public detail only serves published, started, active information without author fields', function () {
    $birdeptId = DB::table('birdepts')->insertGetId([
        'nama_birdept' => 'Media Branding',
        'nama_panggilan' => 'medbrand',
        'jenis' => 'biro',
    ], 'idbirdept');
    $authorId = DB::table('users')->insertGetId([
        'username' => 'author1',
        'password' => bcrypt('secret-password'),
        'email' => 'private-author@example.test',
        'name' => 'Penulis',
        'nim' => '12345678',
    ]);
    $base = [
        'idbirdept' => $birdeptId,
        'iduser' => $authorId,
        'deskripsi' => 'Isi pengumuman',
        'jenis_informasi' => 'kegiatan',
    ];
    $publishedId = DB::table('informasi')->insertGetId($base + [
        'judul' => 'Pengumuman terbuka',
        'slug' => 'pengumuman-terbuka',
        'status' => 'published',
        'waktu_publikasi' => now()->subDay(),
    ]);
    DB::table('informasi')->insert($base + [
        'judul' => 'Draft rahasia',
        'slug' => 'draft-rahasia',
        'status' => 'draft',
        'waktu_publikasi' => now()->subDay(),
    ]);
    DB::table('informasi')->insert($base + [
        'judul' => 'Terjadwal',
        'slug' => 'terjadwal',
        'status' => 'published',
        'waktu_publikasi' => now()->addDay(),
    ]);
    DB::table('informasi')->insert($base + [
        'judul' => 'Kedaluwarsa',
        'slug' => 'kedaluwarsa',
        'status' => 'published',
        'waktu_publikasi' => now()->subDays(2),
        'tanggal_kadaluarsa' => now()->subDay(),
    ]);

    $this->get(route('informasi.show', 'pengumuman-terbuka'))
        ->assertOk()
        ->assertSee('Pengumuman terbuka')
        ->assertDontSee('private-author@example.test');
    $this->get(route('informasi.show', $publishedId))->assertOk();
    $this->get(route('informasi.show', 'draft-rahasia'))->assertNotFound();
    $this->get(route('informasi.show', 'terjadwal'))->assertNotFound();
    $this->get(route('informasi.show', 'kedaluwarsa'))->assertNotFound();

    $this->get(route('home'))->assertOk()->assertDontSee('Draft rahasia')->assertDontSee('Terjadwal')->assertDontSee('Kedaluwarsa');
});

test('a collaborating birdept also displays a shared proker', function () {
    $primary = DB::table('birdepts')->insertGetId(['nama_birdept' => 'Media Branding', 'nama_panggilan' => 'medbrand', 'jenis' => 'biro'], 'idbirdept');
    $collaborator = DB::table('birdepts')->insertGetId(['nama_birdept' => 'Riset dan Teknologi', 'nama_panggilan' => 'rizztek', 'jenis' => 'biro'], 'idbirdept');
    $author = DB::table('users')->insertGetId(['username' => 'author2', 'password' => bcrypt('secret-password'), 'email' => 'author2@example.test', 'name' => 'Penulis', 'nim' => '87654321']);
    $proker = DB::table('informasi')->insertGetId([
        'idbirdept' => $primary,
        'iduser' => $author,
        'judul' => 'Program Kolaborasi',
        'deskripsi' => 'Dua birdept',
        'jenis_informasi' => 'proker',
        'status' => 'published',
        'waktu_publikasi' => now()->subDay(),
    ]);
    DB::table('informasi_birdepts')->insert([
        ['informasi_id' => $proker, 'birdept_id' => $collaborator],
    ]);

    $this->get('/birdept/medbrand')->assertOk()->assertSee('Program Kolaborasi');
    $this->get('/birdept/rizztek')->assertOk()->assertSee('Program Kolaborasi');
});
