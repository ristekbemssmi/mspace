<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserBem extends Model
{
    use HasFactory;

    protected $table = 'users_bem';
    public $timestamps = false;
    public $incrementing = false;

    protected $fillable = [
        'id',
        'idbirdept',
        'jabatan',
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'id', 'id');
    }

    public function birdept()
    {
        return $this->belongsTo(Birdept::class, 'idbirdept', 'idbirdept');
    }
}
