import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\CsvImportController::index
 * @see app/Http/Controllers/Admin/CsvImportController.php:22
 * @route '/admin/csv-hub'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/csv-hub',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CsvImportController::index
 * @see app/Http/Controllers/Admin/CsvImportController.php:22
 * @route '/admin/csv-hub'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CsvImportController::index
 * @see app/Http/Controllers/Admin/CsvImportController.php:22
 * @route '/admin/csv-hub'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\CsvImportController::index
 * @see app/Http/Controllers/Admin/CsvImportController.php:22
 * @route '/admin/csv-hub'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\CsvImportController::index
 * @see app/Http/Controllers/Admin/CsvImportController.php:22
 * @route '/admin/csv-hub'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\CsvImportController::index
 * @see app/Http/Controllers/Admin/CsvImportController.php:22
 * @route '/admin/csv-hub'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\CsvImportController::index
 * @see app/Http/Controllers/Admin/CsvImportController.php:22
 * @route '/admin/csv-hub'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\CsvImportController::process
 * @see app/Http/Controllers/Admin/CsvImportController.php:31
 * @route '/admin/csv-hub/process'
 */
export const process = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: process.url(options),
    method: 'post',
})

process.definition = {
    methods: ["post"],
    url: '/admin/csv-hub/process',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\CsvImportController::process
 * @see app/Http/Controllers/Admin/CsvImportController.php:31
 * @route '/admin/csv-hub/process'
 */
process.url = (options?: RouteQueryOptions) => {
    return process.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CsvImportController::process
 * @see app/Http/Controllers/Admin/CsvImportController.php:31
 * @route '/admin/csv-hub/process'
 */
process.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: process.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\CsvImportController::process
 * @see app/Http/Controllers/Admin/CsvImportController.php:31
 * @route '/admin/csv-hub/process'
 */
    const processForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: process.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\CsvImportController::process
 * @see app/Http/Controllers/Admin/CsvImportController.php:31
 * @route '/admin/csv-hub/process'
 */
        processForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: process.url(options),
            method: 'post',
        })
    
    process.form = processForm
/**
* @see \App\Http\Controllers\Admin\CsvImportController::template
 * @see app/Http/Controllers/Admin/CsvImportController.php:69
 * @route '/admin/csv-hub/template/{tableName}'
 */
export const template = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: template.url(args, options),
    method: 'get',
})

template.definition = {
    methods: ["get","head"],
    url: '/admin/csv-hub/template/{tableName}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CsvImportController::template
 * @see app/Http/Controllers/Admin/CsvImportController.php:69
 * @route '/admin/csv-hub/template/{tableName}'
 */
template.url = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { tableName: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    tableName: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        tableName: args.tableName,
                }

    return template.definition.url
            .replace('{tableName}', parsedArgs.tableName.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CsvImportController::template
 * @see app/Http/Controllers/Admin/CsvImportController.php:69
 * @route '/admin/csv-hub/template/{tableName}'
 */
template.get = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: template.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\CsvImportController::template
 * @see app/Http/Controllers/Admin/CsvImportController.php:69
 * @route '/admin/csv-hub/template/{tableName}'
 */
template.head = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: template.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\CsvImportController::template
 * @see app/Http/Controllers/Admin/CsvImportController.php:69
 * @route '/admin/csv-hub/template/{tableName}'
 */
    const templateForm = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: template.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\CsvImportController::template
 * @see app/Http/Controllers/Admin/CsvImportController.php:69
 * @route '/admin/csv-hub/template/{tableName}'
 */
        templateForm.get = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: template.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\CsvImportController::template
 * @see app/Http/Controllers/Admin/CsvImportController.php:69
 * @route '/admin/csv-hub/template/{tableName}'
 */
        templateForm.head = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: template.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    template.form = templateForm
/**
* @see \App\Http\Controllers\Admin\CsvImportController::templateXlsx
 * @see app/Http/Controllers/Admin/CsvImportController.php:58
 * @route '/admin/csv-hub/template-xlsx/{tableName}'
 */
export const templateXlsx = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: templateXlsx.url(args, options),
    method: 'get',
})

templateXlsx.definition = {
    methods: ["get","head"],
    url: '/admin/csv-hub/template-xlsx/{tableName}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CsvImportController::templateXlsx
 * @see app/Http/Controllers/Admin/CsvImportController.php:58
 * @route '/admin/csv-hub/template-xlsx/{tableName}'
 */
templateXlsx.url = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { tableName: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    tableName: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        tableName: args.tableName,
                }

    return templateXlsx.definition.url
            .replace('{tableName}', parsedArgs.tableName.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CsvImportController::templateXlsx
 * @see app/Http/Controllers/Admin/CsvImportController.php:58
 * @route '/admin/csv-hub/template-xlsx/{tableName}'
 */
templateXlsx.get = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: templateXlsx.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\CsvImportController::templateXlsx
 * @see app/Http/Controllers/Admin/CsvImportController.php:58
 * @route '/admin/csv-hub/template-xlsx/{tableName}'
 */
templateXlsx.head = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: templateXlsx.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\CsvImportController::templateXlsx
 * @see app/Http/Controllers/Admin/CsvImportController.php:58
 * @route '/admin/csv-hub/template-xlsx/{tableName}'
 */
    const templateXlsxForm = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: templateXlsx.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\CsvImportController::templateXlsx
 * @see app/Http/Controllers/Admin/CsvImportController.php:58
 * @route '/admin/csv-hub/template-xlsx/{tableName}'
 */
        templateXlsxForm.get = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: templateXlsx.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\CsvImportController::templateXlsx
 * @see app/Http/Controllers/Admin/CsvImportController.php:58
 * @route '/admin/csv-hub/template-xlsx/{tableName}'
 */
        templateXlsxForm.head = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: templateXlsx.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    templateXlsx.form = templateXlsxForm
/**
* @see \App\Http\Controllers\Admin\CsvImportController::exportMethod
 * @see app/Http/Controllers/Admin/CsvImportController.php:80
 * @route '/admin/csv-hub/export/{tableName}'
 */
export const exportMethod = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(args, options),
    method: 'get',
})

exportMethod.definition = {
    methods: ["get","head"],
    url: '/admin/csv-hub/export/{tableName}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CsvImportController::exportMethod
 * @see app/Http/Controllers/Admin/CsvImportController.php:80
 * @route '/admin/csv-hub/export/{tableName}'
 */
exportMethod.url = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { tableName: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    tableName: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        tableName: args.tableName,
                }

    return exportMethod.definition.url
            .replace('{tableName}', parsedArgs.tableName.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CsvImportController::exportMethod
 * @see app/Http/Controllers/Admin/CsvImportController.php:80
 * @route '/admin/csv-hub/export/{tableName}'
 */
exportMethod.get = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\CsvImportController::exportMethod
 * @see app/Http/Controllers/Admin/CsvImportController.php:80
 * @route '/admin/csv-hub/export/{tableName}'
 */
exportMethod.head = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportMethod.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\CsvImportController::exportMethod
 * @see app/Http/Controllers/Admin/CsvImportController.php:80
 * @route '/admin/csv-hub/export/{tableName}'
 */
    const exportMethodForm = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportMethod.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\CsvImportController::exportMethod
 * @see app/Http/Controllers/Admin/CsvImportController.php:80
 * @route '/admin/csv-hub/export/{tableName}'
 */
        exportMethodForm.get = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\CsvImportController::exportMethod
 * @see app/Http/Controllers/Admin/CsvImportController.php:80
 * @route '/admin/csv-hub/export/{tableName}'
 */
        exportMethodForm.head = (args: { tableName: string | number } | [tableName: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportMethod.form = exportMethodForm
const csvHub = {
    index: Object.assign(index, index),
process: Object.assign(process, process),
template: Object.assign(template, template),
templateXlsx: Object.assign(templateXlsx, templateXlsx),
export: Object.assign(exportMethod, exportMethod),
}

export default csvHub