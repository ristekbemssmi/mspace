import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\BirdeptController::index
 * @see app/Http/Controllers/Admin/BirdeptController.php:24
 * @route '/admin/birdept'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/birdept',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\BirdeptController::index
 * @see app/Http/Controllers/Admin/BirdeptController.php:24
 * @route '/admin/birdept'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BirdeptController::index
 * @see app/Http/Controllers/Admin/BirdeptController.php:24
 * @route '/admin/birdept'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\BirdeptController::index
 * @see app/Http/Controllers/Admin/BirdeptController.php:24
 * @route '/admin/birdept'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\BirdeptController::index
 * @see app/Http/Controllers/Admin/BirdeptController.php:24
 * @route '/admin/birdept'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\BirdeptController::index
 * @see app/Http/Controllers/Admin/BirdeptController.php:24
 * @route '/admin/birdept'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\BirdeptController::index
 * @see app/Http/Controllers/Admin/BirdeptController.php:24
 * @route '/admin/birdept'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\BirdeptController::store
 * @see app/Http/Controllers/Admin/BirdeptController.php:46
 * @route '/admin/birdept'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/birdept',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\BirdeptController::store
 * @see app/Http/Controllers/Admin/BirdeptController.php:46
 * @route '/admin/birdept'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BirdeptController::store
 * @see app/Http/Controllers/Admin/BirdeptController.php:46
 * @route '/admin/birdept'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\BirdeptController::store
 * @see app/Http/Controllers/Admin/BirdeptController.php:46
 * @route '/admin/birdept'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BirdeptController::store
 * @see app/Http/Controllers/Admin/BirdeptController.php:46
 * @route '/admin/birdept'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\BirdeptController::update
 * @see app/Http/Controllers/Admin/BirdeptController.php:61
 * @route '/admin/birdept/{id}'
 */
export const update = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/birdept/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\BirdeptController::update
 * @see app/Http/Controllers/Admin/BirdeptController.php:61
 * @route '/admin/birdept/{id}'
 */
update.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return update.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BirdeptController::update
 * @see app/Http/Controllers/Admin/BirdeptController.php:61
 * @route '/admin/birdept/{id}'
 */
update.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\BirdeptController::update
 * @see app/Http/Controllers/Admin/BirdeptController.php:61
 * @route '/admin/birdept/{id}'
 */
    const updateForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BirdeptController::update
 * @see app/Http/Controllers/Admin/BirdeptController.php:61
 * @route '/admin/birdept/{id}'
 */
        updateForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\BirdeptController::destroy
 * @see app/Http/Controllers/Admin/BirdeptController.php:78
 * @route '/admin/birdept/{id}'
 */
export const destroy = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/birdept/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\BirdeptController::destroy
 * @see app/Http/Controllers/Admin/BirdeptController.php:78
 * @route '/admin/birdept/{id}'
 */
destroy.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return destroy.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BirdeptController::destroy
 * @see app/Http/Controllers/Admin/BirdeptController.php:78
 * @route '/admin/birdept/{id}'
 */
destroy.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\BirdeptController::destroy
 * @see app/Http/Controllers/Admin/BirdeptController.php:78
 * @route '/admin/birdept/{id}'
 */
    const destroyForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BirdeptController::destroy
 * @see app/Http/Controllers/Admin/BirdeptController.php:78
 * @route '/admin/birdept/{id}'
 */
        destroyForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Admin\BirdeptController::importCsv
 * @see app/Http/Controllers/Admin/BirdeptController.php:86
 * @route '/admin/birdept/import-csv'
 */
export const importCsv = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: importCsv.url(options),
    method: 'post',
})

importCsv.definition = {
    methods: ["post"],
    url: '/admin/birdept/import-csv',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\BirdeptController::importCsv
 * @see app/Http/Controllers/Admin/BirdeptController.php:86
 * @route '/admin/birdept/import-csv'
 */
importCsv.url = (options?: RouteQueryOptions) => {
    return importCsv.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BirdeptController::importCsv
 * @see app/Http/Controllers/Admin/BirdeptController.php:86
 * @route '/admin/birdept/import-csv'
 */
importCsv.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: importCsv.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\BirdeptController::importCsv
 * @see app/Http/Controllers/Admin/BirdeptController.php:86
 * @route '/admin/birdept/import-csv'
 */
    const importCsvForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: importCsv.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BirdeptController::importCsv
 * @see app/Http/Controllers/Admin/BirdeptController.php:86
 * @route '/admin/birdept/import-csv'
 */
        importCsvForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: importCsv.url(options),
            method: 'post',
        })
    
    importCsv.form = importCsvForm
/**
* @see \App\Http\Controllers\Admin\BirdeptController::templateCsv
 * @see app/Http/Controllers/Admin/BirdeptController.php:101
 * @route '/admin/birdept/template-csv'
 */
export const templateCsv = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: templateCsv.url(options),
    method: 'get',
})

templateCsv.definition = {
    methods: ["get","head"],
    url: '/admin/birdept/template-csv',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\BirdeptController::templateCsv
 * @see app/Http/Controllers/Admin/BirdeptController.php:101
 * @route '/admin/birdept/template-csv'
 */
templateCsv.url = (options?: RouteQueryOptions) => {
    return templateCsv.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BirdeptController::templateCsv
 * @see app/Http/Controllers/Admin/BirdeptController.php:101
 * @route '/admin/birdept/template-csv'
 */
templateCsv.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: templateCsv.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\BirdeptController::templateCsv
 * @see app/Http/Controllers/Admin/BirdeptController.php:101
 * @route '/admin/birdept/template-csv'
 */
templateCsv.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: templateCsv.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\BirdeptController::templateCsv
 * @see app/Http/Controllers/Admin/BirdeptController.php:101
 * @route '/admin/birdept/template-csv'
 */
    const templateCsvForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: templateCsv.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\BirdeptController::templateCsv
 * @see app/Http/Controllers/Admin/BirdeptController.php:101
 * @route '/admin/birdept/template-csv'
 */
        templateCsvForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: templateCsv.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\BirdeptController::templateCsv
 * @see app/Http/Controllers/Admin/BirdeptController.php:101
 * @route '/admin/birdept/template-csv'
 */
        templateCsvForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: templateCsv.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    templateCsv.form = templateCsvForm
/**
* @see \App\Http\Controllers\Admin\BirdeptController::exportCsv
 * @see app/Http/Controllers/Admin/BirdeptController.php:112
 * @route '/admin/birdept/export-csv'
 */
export const exportCsv = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportCsv.url(options),
    method: 'get',
})

exportCsv.definition = {
    methods: ["get","head"],
    url: '/admin/birdept/export-csv',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\BirdeptController::exportCsv
 * @see app/Http/Controllers/Admin/BirdeptController.php:112
 * @route '/admin/birdept/export-csv'
 */
exportCsv.url = (options?: RouteQueryOptions) => {
    return exportCsv.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BirdeptController::exportCsv
 * @see app/Http/Controllers/Admin/BirdeptController.php:112
 * @route '/admin/birdept/export-csv'
 */
exportCsv.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportCsv.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\BirdeptController::exportCsv
 * @see app/Http/Controllers/Admin/BirdeptController.php:112
 * @route '/admin/birdept/export-csv'
 */
exportCsv.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportCsv.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\BirdeptController::exportCsv
 * @see app/Http/Controllers/Admin/BirdeptController.php:112
 * @route '/admin/birdept/export-csv'
 */
    const exportCsvForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportCsv.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\BirdeptController::exportCsv
 * @see app/Http/Controllers/Admin/BirdeptController.php:112
 * @route '/admin/birdept/export-csv'
 */
        exportCsvForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportCsv.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\BirdeptController::exportCsv
 * @see app/Http/Controllers/Admin/BirdeptController.php:112
 * @route '/admin/birdept/export-csv'
 */
        exportCsvForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportCsv.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportCsv.form = exportCsvForm
const birdept = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
importCsv: Object.assign(importCsv, importCsv),
templateCsv: Object.assign(templateCsv, templateCsv),
exportCsv: Object.assign(exportCsv, exportCsv),
}

export default birdept