import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\InformasiController::show
 * @see app/Http/Controllers/InformasiController.php:11
 * @route '/informasi/{identifier}'
 */
export const show = (args: { identifier: string | number } | [identifier: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/informasi/{identifier}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\InformasiController::show
 * @see app/Http/Controllers/InformasiController.php:11
 * @route '/informasi/{identifier}'
 */
show.url = (args: { identifier: string | number } | [identifier: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { identifier: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    identifier: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        identifier: args.identifier,
                }

    return show.definition.url
            .replace('{identifier}', parsedArgs.identifier.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InformasiController::show
 * @see app/Http/Controllers/InformasiController.php:11
 * @route '/informasi/{identifier}'
 */
show.get = (args: { identifier: string | number } | [identifier: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\InformasiController::show
 * @see app/Http/Controllers/InformasiController.php:11
 * @route '/informasi/{identifier}'
 */
show.head = (args: { identifier: string | number } | [identifier: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\InformasiController::show
 * @see app/Http/Controllers/InformasiController.php:11
 * @route '/informasi/{identifier}'
 */
    const showForm = (args: { identifier: string | number } | [identifier: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\InformasiController::show
 * @see app/Http/Controllers/InformasiController.php:11
 * @route '/informasi/{identifier}'
 */
        showForm.get = (args: { identifier: string | number } | [identifier: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\InformasiController::show
 * @see app/Http/Controllers/InformasiController.php:11
 * @route '/informasi/{identifier}'
 */
        showForm.head = (args: { identifier: string | number } | [identifier: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const informasi = {
    show: Object.assign(show, show),
}

export default informasi