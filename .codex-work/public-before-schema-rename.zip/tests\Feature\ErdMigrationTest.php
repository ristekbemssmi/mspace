<?php

use App\Services\ErdBackfillService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

uses(RefreshDatabase::class);

test('ERD v2 preserves legacy content and backfills people, membership, slugs, and baseline revisions once', function () {
    expect(Schema::hasTable('people'))->toBeTrue();
    expect(Schema::hasTable('documents'))->toBeTrue();
    expect(Schema::hasTable('audit_events'))->toBeTrue();

    $birdeptId = DB::table('birdepts')->insertGetId([
        'nama_birdept' => 'Media Branding',
        'nama_panggilan' => 'medbrand',
        'jenis' => 'biro',
    ], 'idbirdept');
    $userId = DB::table('users')->insertGetId([
        'username' => 'editor1',
        'password' => bcrypt('secret-password'),
        'email' => 'editor@example.test',
        'name' => 'Editor Satu',
        'nim' => '12345678',
        'prodi' => 'Ilmu Komputer',
    ]);
    DB::table('users_bem')->insert(['id' => $userId, 'idbirdept' => $birdeptId, 'jabatan' => 'Staff']);
    $infoId = DB::table('informasi')->insertGetId([
        'idbirdept' => $birdeptId,
        'iduser' => $userId,
        'judul' => 'Kegiatan M Space',
        'deskripsi' => 'Informasi kegiatan',
        'status' => 'published',
        'jenis_informasi' => 'proker',
        'waktu_publikasi' => now(),
    ]);

    $service = app(ErdBackfillService::class);
    $service->run();
    $service->run();

    $this->assertDatabaseCount('people', 1);
    $this->assertDatabaseCount('memberships', 1);
    $this->assertDatabaseCount('content_revisions', 1);
    $this->assertDatabaseHas('informasi', ['id' => $infoId, 'slug' => 'kegiatan-m-space-'.$infoId]);
    $this->assertDatabaseHas('users', ['id' => $userId, 'prodi_id' => DB::table('prodis')->where('nama', 'Ilmu Komputer')->value('id')]);
});
