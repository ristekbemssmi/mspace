<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InformasiAlumni extends Model
{
    use HasFactory;

    protected $table = 'informasi_alumni';
    public $timestamps = false;
    public $incrementing = false;

    protected $fillable = [
        'id',
        'nama_alumni',
        'angkatan',
        'topik_sharing',
    ];

    public function informasi()
    {
        return $this->belongsTo(Informasi::class, 'id', 'id');
    }
}
