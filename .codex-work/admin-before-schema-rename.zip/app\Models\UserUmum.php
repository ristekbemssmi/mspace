<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserUmum extends Model
{
    use HasFactory;

    protected $table = 'users_umum';
    public $timestamps = false;
    public $incrementing = false;

    protected $fillable = [
        'id',
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'id', 'id');
    }
}
