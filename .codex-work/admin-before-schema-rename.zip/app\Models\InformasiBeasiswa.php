<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InformasiBeasiswa extends Model
{
    use HasFactory;

    protected $table = 'informasi_beasiswa';
    public $timestamps = false;
    public $incrementing = false;

    protected $fillable = [
        'id',
        'penyelenggara',
        'tanggal_buka',
        'tanggal_tutup',
        'link_poster',
        'link_instagram',
        'link_pendaftaran',
    ];

    public function informasi()
    {
        return $this->belongsTo(Informasi::class, 'id', 'id');
    }

    public function syarat()
    {
        return $this->hasMany(SyaratBeasiswa::class, 'id_beasiswa', 'id');
    }

    public function benefit()
    {
        return $this->hasMany(BenefitBeasiswa::class, 'id_beasiswa', 'id');
    }
}
