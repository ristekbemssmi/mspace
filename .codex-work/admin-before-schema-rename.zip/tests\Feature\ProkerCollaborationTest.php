<?php

use App\Models\Birdept;
use App\Models\Informasi;
use App\Models\User;

test('a proker can be managed by a primary birdept and a collaborator', function () {
    $editor = User::factory()->create();
    $editor->forceFill(['admin_role' => 'editor'])->save();
    $primary = Birdept::create(['nama_birdept' => 'Media Branding', 'nama_panggilan' => 'Medbrand', 'jenis' => 'biro']);
    $collaborator = Birdept::create(['nama_birdept' => 'Riset dan Teknologi', 'nama_panggilan' => 'Rizztek', 'jenis' => 'biro']);

    $payload = [
        'idbirdept' => $primary->idbirdept,
        'birdept_ids' => [$collaborator->idbirdept],
        'judul' => 'Proker bersama',
        'deskripsi' => 'Dikerjakan oleh dua birdept',
        'jenis_informasi' => 'proker',
        'status' => 'draft',
    ];

    $this->actingAs($editor)->post(route('admin.informasi.store'), $payload)->assertRedirect();
    $info = Informasi::sole();
    expect($info->idbirdept)->toBe($primary->idbirdept);
    expect($info->birdepts()->pluck('birdepts.idbirdept')->all())->toBe([$collaborator->idbirdept]);

    $this->actingAs($editor)->put(route('admin.informasi.update', $info->id), [
        ...$payload,
        'birdept_ids' => [],
    ])->assertRedirect();
    expect($info->fresh()->birdepts()->count())->toBe(0);

    $this->actingAs($editor)->put(route('admin.informasi.update', $info->id), [
        ...$payload,
        'birdept_ids' => [999999],
    ])->assertSessionHasErrors('birdept_ids.0');
});
