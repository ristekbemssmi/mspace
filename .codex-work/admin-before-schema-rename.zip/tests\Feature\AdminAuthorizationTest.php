<?php

use App\Models\Birdept;
use App\Models\Informasi;
use App\Models\User;

test('ordinary accounts cannot use dashboard actions', function () {
    $user = User::factory()->create();

    $this->actingAs($user)->get(route('admin.users.index'))->assertForbidden();
    $this->actingAs($user)->get(route('admin.users.export-csv'))->assertForbidden();
    $this->actingAs($user)->post(route('admin.csv-hub.process'))->assertForbidden();
});

test('viewer can read content but cannot modify or export it', function () {
    $viewer = User::factory()->create();
    $viewer->forceFill(['admin_role' => 'viewer'])->save();

    $this->actingAs($viewer)->get(route('admin.informasi.index'))->assertOk();
    $this->actingAs($viewer)->get(route('admin.users.index'))->assertForbidden();
    $this->actingAs($viewer)->post(route('admin.faqs.store'))->assertForbidden();
    $this->actingAs($viewer)->get(route('admin.informasi.export-csv'))->assertForbidden();
});

test('editor can create a draft only under their own author identity', function () {
    $editor = User::factory()->create();
    $editor->forceFill(['admin_role' => 'editor'])->save();
    $other = User::factory()->create();
    $birdept = Birdept::create([
        'nama_birdept' => 'Media Branding',
        'nama_panggilan' => 'medbrand',
        'jenis' => 'biro',
    ]);

    $payload = [
        'idbirdept' => $birdept->idbirdept,
        'iduser' => $other->id,
        'judul' => 'Contoh draft',
        'deskripsi' => 'Deskripsi contoh',
        'jenis_informasi' => 'proker',
        'status' => 'draft',
    ];

    $this->actingAs($editor)->post(route('admin.informasi.store'), $payload)->assertRedirect();
    expect(Informasi::sole()->iduser)->toBe($editor->id);

    $this->actingAs($editor)->post(route('admin.informasi.store'), [
        ...$payload,
        'judul' => 'Publikasi terlarang',
        'status' => 'published',
    ])->assertForbidden();
    $this->actingAs($editor)->get(route('admin.csv-hub.export', 'users'))->assertForbidden();
});

test('account export omits credentials and two factor secrets', function () {
    $admin = User::factory()->create();
    $admin->forceFill(['admin_role' => 'admin'])->save();

    $response = $this->actingAs($admin)->get(route('admin.users.export-csv'));
    $response->assertOk();
    $csv = $response->streamedContent();

    expect($csv)->toContain('username,name,email,nim');
    expect($csv)->not->toContain('password', 'remember_token', 'two_factor_secret', 'two_factor_recovery_codes');

    $this->actingAs($admin)->delete(route('admin.users.destroy', $admin->id))->assertForbidden();
});

test('editor cannot change another editor draft', function () {
    $author = User::factory()->create();
    $author->forceFill(['admin_role' => 'editor'])->save();
    $other = User::factory()->create();
    $other->forceFill(['admin_role' => 'editor'])->save();
    $birdept = Birdept::create([
        'nama_birdept' => 'Media Branding',
        'nama_panggilan' => 'medbrand',
        'jenis' => 'biro',
    ]);
    $info = Informasi::create([
        'idbirdept' => $birdept->idbirdept,
        'iduser' => $author->id,
        'judul' => 'Draft asli',
        'deskripsi' => 'Isi asli',
        'jenis_informasi' => 'proker',
        'status' => 'draft',
        'waktu_publikasi' => now(),
    ]);

    $payload = [
        'idbirdept' => $birdept->idbirdept,
        'judul' => 'Draft diubah',
        'deskripsi' => 'Isi diubah',
        'jenis_informasi' => 'proker',
        'status' => 'draft',
    ];

    $this->actingAs($other)->put(route('admin.informasi.update', $info->id), $payload)->assertForbidden();
    $this->actingAs($author)->put(route('admin.informasi.update', $info->id), $payload)->assertRedirect();
    expect($info->fresh()->judul)->toBe('Draft diubah');
});
test('viewer responses do not expose another account contact details', function () {
    $viewer = User::factory()->create();
    $viewer->forceFill(['admin_role' => 'viewer'])->save();
    User::factory()->create(['email' => 'private-author@example.test']);

    $this->actingAs($viewer)->get(route('admin.dashboard'))
        ->assertOk()
        ->assertDontSee('private-author@example.test');
    $this->actingAs($viewer)->get(route('admin.informasi.index'))
        ->assertOk()
        ->assertDontSee('private-author@example.test');
});