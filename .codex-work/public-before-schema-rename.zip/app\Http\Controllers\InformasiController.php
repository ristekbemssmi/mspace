<?php

namespace App\Http\Controllers;

use App\Models\Informasi;
use Inertia\Inertia;
use Inertia\Response;

class InformasiController extends Controller
{
    public function show(string $identifier): Response
    {
        $informasi = Informasi::query()
            ->select(Informasi::PUBLIC_COLUMNS)
            ->published()
            ->active()
            ->where(function ($query) use ($identifier): void {
                $query->where('slug', $identifier);
                if (ctype_digit($identifier)) {
                    $query->orWhere('id', (int) $identifier);
                }
            })
            ->with([
                'birdept:idbirdept,nama_birdept,nama_panggilan',
                'birdepts:idbirdept,nama_birdept,nama_panggilan',
                'beasiswa:id,penyelenggara,tanggal_buka,tanggal_tutup,link_pendaftaran',
                'beasiswa.syaratBeasiswa:id,id_beasiswa,nama_syarat,keterangan',
                'beasiswa.benefitBeasiswa:id,id_beasiswa,nama_benefit,keterangan',
            ])
            ->firstOrFail();

        return Inertia::render('Informasi/Show', ['informasi' => $informasi]);
    }
}
