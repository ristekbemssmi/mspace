import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/akademik'
 */
const Controller63cf85988e5fe4426a74d039c42b4e96 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller63cf85988e5fe4426a74d039c42b4e96.url(options),
    method: 'get',
})

Controller63cf85988e5fe4426a74d039c42b4e96.definition = {
    methods: ["get","head"],
    url: '/akademik',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/akademik'
 */
Controller63cf85988e5fe4426a74d039c42b4e96.url = (options?: RouteQueryOptions) => {
    return Controller63cf85988e5fe4426a74d039c42b4e96.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/akademik'
 */
Controller63cf85988e5fe4426a74d039c42b4e96.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller63cf85988e5fe4426a74d039c42b4e96.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/akademik'
 */
Controller63cf85988e5fe4426a74d039c42b4e96.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller63cf85988e5fe4426a74d039c42b4e96.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/akademik'
 */
    const Controller63cf85988e5fe4426a74d039c42b4e96Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: Controller63cf85988e5fe4426a74d039c42b4e96.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/akademik'
 */
        Controller63cf85988e5fe4426a74d039c42b4e96Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller63cf85988e5fe4426a74d039c42b4e96.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/akademik'
 */
        Controller63cf85988e5fe4426a74d039c42b4e96Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller63cf85988e5fe4426a74d039c42b4e96.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    Controller63cf85988e5fe4426a74d039c42b4e96.form = Controller63cf85988e5fe4426a74d039c42b4e96Form
    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-wisuda'
 */
const Controller9a4c359d319bda09aefd4aba60ff941d = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller9a4c359d319bda09aefd4aba60ff941d.url(options),
    method: 'get',
})

Controller9a4c359d319bda09aefd4aba60ff941d.definition = {
    methods: ["get","head"],
    url: '/informasi-wisuda',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-wisuda'
 */
Controller9a4c359d319bda09aefd4aba60ff941d.url = (options?: RouteQueryOptions) => {
    return Controller9a4c359d319bda09aefd4aba60ff941d.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-wisuda'
 */
Controller9a4c359d319bda09aefd4aba60ff941d.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller9a4c359d319bda09aefd4aba60ff941d.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-wisuda'
 */
Controller9a4c359d319bda09aefd4aba60ff941d.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller9a4c359d319bda09aefd4aba60ff941d.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-wisuda'
 */
    const Controller9a4c359d319bda09aefd4aba60ff941dForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: Controller9a4c359d319bda09aefd4aba60ff941d.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-wisuda'
 */
        Controller9a4c359d319bda09aefd4aba60ff941dForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller9a4c359d319bda09aefd4aba60ff941d.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-wisuda'
 */
        Controller9a4c359d319bda09aefd4aba60ff941dForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller9a4c359d319bda09aefd4aba60ff941d.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    Controller9a4c359d319bda09aefd4aba60ff941d.form = Controller9a4c359d319bda09aefd4aba60ff941dForm
    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-alumni'
 */
const Controller5ee14190043f5decdaa1e49f3403745d = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller5ee14190043f5decdaa1e49f3403745d.url(options),
    method: 'get',
})

Controller5ee14190043f5decdaa1e49f3403745d.definition = {
    methods: ["get","head"],
    url: '/informasi-alumni',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-alumni'
 */
Controller5ee14190043f5decdaa1e49f3403745d.url = (options?: RouteQueryOptions) => {
    return Controller5ee14190043f5decdaa1e49f3403745d.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-alumni'
 */
Controller5ee14190043f5decdaa1e49f3403745d.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller5ee14190043f5decdaa1e49f3403745d.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-alumni'
 */
Controller5ee14190043f5decdaa1e49f3403745d.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller5ee14190043f5decdaa1e49f3403745d.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-alumni'
 */
    const Controller5ee14190043f5decdaa1e49f3403745dForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: Controller5ee14190043f5decdaa1e49f3403745d.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-alumni'
 */
        Controller5ee14190043f5decdaa1e49f3403745dForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller5ee14190043f5decdaa1e49f3403745d.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-alumni'
 */
        Controller5ee14190043f5decdaa1e49f3403745dForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller5ee14190043f5decdaa1e49f3403745d.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    Controller5ee14190043f5decdaa1e49f3403745d.form = Controller5ee14190043f5decdaa1e49f3403745dForm
    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-magang'
 */
const Controllerf3befca8ee18fadd2a65d31261244331 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllerf3befca8ee18fadd2a65d31261244331.url(options),
    method: 'get',
})

Controllerf3befca8ee18fadd2a65d31261244331.definition = {
    methods: ["get","head"],
    url: '/informasi-magang',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-magang'
 */
Controllerf3befca8ee18fadd2a65d31261244331.url = (options?: RouteQueryOptions) => {
    return Controllerf3befca8ee18fadd2a65d31261244331.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-magang'
 */
Controllerf3befca8ee18fadd2a65d31261244331.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllerf3befca8ee18fadd2a65d31261244331.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-magang'
 */
Controllerf3befca8ee18fadd2a65d31261244331.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controllerf3befca8ee18fadd2a65d31261244331.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-magang'
 */
    const Controllerf3befca8ee18fadd2a65d31261244331Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: Controllerf3befca8ee18fadd2a65d31261244331.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-magang'
 */
        Controllerf3befca8ee18fadd2a65d31261244331Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controllerf3befca8ee18fadd2a65d31261244331.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-magang'
 */
        Controllerf3befca8ee18fadd2a65d31261244331Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controllerf3befca8ee18fadd2a65d31261244331.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    Controllerf3befca8ee18fadd2a65d31261244331.form = Controllerf3befca8ee18fadd2a65d31261244331Form
    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-kegiatan'
 */
const Controller25fe3150ce55e0a18d89e0a5268691db = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller25fe3150ce55e0a18d89e0a5268691db.url(options),
    method: 'get',
})

Controller25fe3150ce55e0a18d89e0a5268691db.definition = {
    methods: ["get","head"],
    url: '/informasi-kegiatan',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-kegiatan'
 */
Controller25fe3150ce55e0a18d89e0a5268691db.url = (options?: RouteQueryOptions) => {
    return Controller25fe3150ce55e0a18d89e0a5268691db.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-kegiatan'
 */
Controller25fe3150ce55e0a18d89e0a5268691db.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller25fe3150ce55e0a18d89e0a5268691db.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-kegiatan'
 */
Controller25fe3150ce55e0a18d89e0a5268691db.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller25fe3150ce55e0a18d89e0a5268691db.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-kegiatan'
 */
    const Controller25fe3150ce55e0a18d89e0a5268691dbForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: Controller25fe3150ce55e0a18d89e0a5268691db.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-kegiatan'
 */
        Controller25fe3150ce55e0a18d89e0a5268691dbForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller25fe3150ce55e0a18d89e0a5268691db.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/informasi-kegiatan'
 */
        Controller25fe3150ce55e0a18d89e0a5268691dbForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller25fe3150ce55e0a18d89e0a5268691db.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    Controller25fe3150ce55e0a18d89e0a5268691db.form = Controller25fe3150ce55e0a18d89e0a5268691dbForm

/**
* Multiple routes resolve to \Inertia\Controller::Controller, so this export is a
* dictionary keyed by URI rather than a callable. Call a specific route with `Controller['<uri>'](...)`,
* or import the route by name from your generated `routes/` directory.
*/
const Controller = {
    '/akademik': Controller63cf85988e5fe4426a74d039c42b4e96,
    '/informasi-wisuda': Controller9a4c359d319bda09aefd4aba60ff941d,
    '/informasi-alumni': Controller5ee14190043f5decdaa1e49f3403745d,
    '/informasi-magang': Controllerf3befca8ee18fadd2a65d31261244331,
    '/informasi-kegiatan': Controller25fe3150ce55e0a18d89e0a5268691db,
}

export default Controller