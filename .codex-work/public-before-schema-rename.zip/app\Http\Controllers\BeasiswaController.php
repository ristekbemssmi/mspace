<?php

namespace App\Http\Controllers;

use App\Models\Informasi;
use Inertia\Inertia;

class BeasiswaController extends Controller
{
    public function index()
    {
        $beasiswa = Informasi::published()
            ->active()
            ->select(Informasi::PUBLIC_COLUMNS)
            ->whereIn('jenis_informasi', ['beasiswa'])
            ->with(['beasiswa.syaratBeasiswa', 'beasiswa.benefitBeasiswa'])
            ->orderBy('created_at', 'desc')
            ->get();

        return Inertia::render('Beasiswa/Index', [
            'beasiswaData' => $beasiswa,
        ]);
    }
}
