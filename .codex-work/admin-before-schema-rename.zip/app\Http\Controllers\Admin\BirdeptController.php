<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Birdept;
use App\Services\CsvService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

use Symfony\Component\HttpFoundation\StreamedResponse;
use Inertia\Inertia;
use Inertia\Response;

class BirdeptController extends Controller
{
    protected CsvService $csvService;

    public function __construct(CsvService $csvService)
    {
        $this->csvService = $csvService;
    }

    public function index(Request $request): Response
    {
        $query = Birdept::query();

        if ($search = $request->input('search')) {
            $query->where('nama_birdept', 'like', "%{$search}%")
                ->orWhere('nama_panggilan', 'like', "%{$search}%")
                ->orWhere('jenis', 'like', "%{$search}%");
        }

        if ($jenis = $request->input('jenis')) {
            $query->where('jenis', $jenis);
        }

        $birdepts = $query->orderBy('jenis')->orderBy('nama_birdept')->get();

        return Inertia::render('admin/birdept/index', [
            'birdepts' => $birdepts,
            'filters' => $request->only(['search', 'jenis']),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'nama_birdept' => 'required|string',
            'nama_panggilan' => 'required|string',
            'jenis' => 'required|in:bph,biro,departemen',
            'deskripsi' => 'nullable|string',
            'instagram' => 'nullable|string',
        ]);

        Birdept::create($validated);

        return redirect()->back()->with('success', 'Birdept berhasil ditambahkan.');
    }

    public function update(Request $request, int $id): RedirectResponse
    {
        $birdept = Birdept::findOrFail($id);

        $validated = $request->validate([
            'nama_birdept' => 'required|string',
            'nama_panggilan' => 'required|string',
            'jenis' => 'required|in:bph,biro,departemen',
            'deskripsi' => 'nullable|string',
            'instagram' => 'nullable|string',
        ]);

        $birdept->update($validated);

        return redirect()->back()->with('success', 'Birdept berhasil diperbarui.');
    }

    public function destroy(int $id): RedirectResponse
    {
        $birdept = Birdept::findOrFail($id);
        $birdept->delete();

        return redirect()->back()->with('success', 'Birdept berhasil dihapus.');
    }

    public function importCsv(Request $request): RedirectResponse
    {
        $request->validate([
            'file' => 'required|file|mimes:xlsx,xls,csv,txt|max:10240',
        ]);

        $result = $this->csvService->importCsv('birdepts', $request->file('file'));

        if (!$result['success']) {
            return redirect()->back()->withErrors(['csv' => $result['message']]);
        }

        return redirect()->back()->with('success', $result['message']);
    }

    public function downloadTemplate(): StreamedResponse
    {
        $csvContent = $this->csvService->generateTemplate('birdepts');

        return response()->streamDownload(function () use ($csvContent) {
            echo $csvContent;
        }, 'template_birdept.csv', [
            'Content-Type' => 'text/csv',
        ]);
    }

    public function exportCsv(): StreamedResponse
    {
        $csvContent = $this->csvService->exportCsv('birdepts');

        return response()->streamDownload(function () use ($csvContent) {
            echo $csvContent;
        }, 'export_birdept_' . date('Y-m-d_H-i-s') . '.csv', [
            'Content-Type' => 'text/csv',
        ]);
    }
}
