<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InformasiProker extends Model
{
    use HasFactory;

    protected $table = 'informasi_proker';
    public $timestamps = false;
    public $incrementing = false;

    protected $fillable = [
        'id',
        'tujuan',
        'sasaran',
        'waktu_mulai',
        'waktu_selesai',
    ];

    public function informasi()
    {
        return $this->belongsTo(Informasi::class, 'id', 'id');
    }

    public function panitia()
    {
        return $this->hasMany(PanitiaProker::class, 'id_proker', 'id');
    }
}
